#!/usr/bin/env python3
"""
=============================================================================
CRITICAL RESOURCES AS MACRO VARIABLES - VISUALIZATION SUITE
=============================================================================
Complete Python code for generating all figures, charts, tables, and 
visualizations for the CEDX Research Report.

Author: CEDX Research Team
Report: RR-CEDX-2025-003
Date: January 2025

Requirements:
    pip install matplotlib numpy

Usage:
    python generate_all_visualizations.py
    
Output:
    All figures saved to ./figures/ directory
=============================================================================
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch
import numpy as np
import os
import warnings
warnings.filterwarnings('ignore')

# =============================================================================
# CONFIGURATION AND STYLING
# =============================================================================

plt.rcParams.update({
    'font.family': 'DejaVu Sans',
    'font.size': 10,
    'axes.titlesize': 12,
    'axes.labelsize': 10,
    'xtick.labelsize': 9,
    'ytick.labelsize': 9,
    'legend.fontsize': 9,
    'figure.titlesize': 14,
    'axes.spines.top': False,
    'axes.spines.right': False,
    'axes.grid': True,
    'grid.alpha': 0.3,
    'grid.linestyle': '--',
    'figure.dpi': 300,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight',
    'savefig.facecolor': 'white',
})

COLORS = {
    'primary': '#1A365D',
    'secondary': '#2B6CB0',
    'accent': '#C05621',
    'positive': '#276749',
    'negative': '#C53030',
    'neutral': '#4A5568',
    'light_bg': '#F7FAFC',
    'highlight': '#D69E2E',
}

OUTPUT_DIR = './figures'
os.makedirs(OUTPUT_DIR, exist_ok=True)

def save_figure(fig, filename):
    filepath = os.path.join(OUTPUT_DIR, filename)
    fig.savefig(filepath, facecolor='white', edgecolor='none')
    plt.close(fig)
    print(f"Saved: {filepath}")
    return filepath

# =============================================================================
# ALL FIGURE GENERATION FUNCTIONS
# =============================================================================

def create_conceptual_framework():
    """Figure 1.1: Conceptual Framework"""
    fig, ax = plt.subplots(figsize=(14, 9))
    ax.set_xlim(0, 14)
    ax.set_ylim(0, 10)
    ax.axis('off')
    
    ax.text(7, 9.5, 'Conceptual Framework: Critical Resources as Macro Production Constraints',
            ha='center', fontsize=14, fontweight='bold', color=COLORS['primary'])
    
    boxes = [
        (2, 7, 'Resource\nEndowment\n(STOCK)', COLORS['primary']),
        (5.5, 7, 'Production\nCapacity\n(FLOW)', COLORS['secondary']),
        (9, 7, 'Economic\nOutput\n(GDP)', COLORS['positive']),
        (12, 7, 'Fiscal\nRevenue', COLORS['highlight']),
    ]
    
    for x, y, text, color in boxes:
        rect = FancyBboxPatch((x-1.2, y-0.9), 2.4, 1.8, boxstyle="round,pad=0.05",
                              facecolor=color, alpha=0.9, edgecolor='white', linewidth=2)
        ax.add_patch(rect)
        ax.text(x, y, text, ha='center', va='center', fontsize=10, color='white', fontweight='bold')
    
    for i in range(len(boxes)-1):
        ax.annotate('', xy=(boxes[i+1][0]-1.3, 7), xytext=(boxes[i][0]+1.3, 7),
                   arrowprops=dict(arrowstyle='->', color=COLORS['neutral'], lw=2.5))
    
    shock_boxes = [
        (2, 3.5, 'Price\nShocks', COLORS['negative']),
        (5.5, 3.5, 'Trade\nBalance', COLORS['neutral']),
        (9, 3.5, 'Inflation\nPressure', COLORS['accent']),
        (12, 3.5, 'Exchange\nRate', COLORS['negative']),
    ]
    
    for x, y, text, color in shock_boxes:
        rect = FancyBboxPatch((x-1.2, y-0.9), 2.4, 1.8, boxstyle="round,pad=0.05",
                              facecolor=color, alpha=0.8, edgecolor='white', linewidth=2)
        ax.add_patch(rect)
        ax.text(x, y, text, ha='center', va='center', fontsize=10, color='white', fontweight='bold')
    
    for i in range(len(boxes)):
        ax.annotate('', xy=(boxes[i][0], 4.4), xytext=(boxes[i][0], 6.1),
                   arrowprops=dict(arrowstyle='->', color=COLORS['neutral'], lw=2))
    
    gov_rect = FancyBboxPatch((4.5, 0.5), 5, 2, boxstyle="round,pad=0.1",
                              facecolor=COLORS['primary'], alpha=0.95, edgecolor='white', linewidth=3)
    ax.add_patch(gov_rect)
    ax.text(7, 1.8, 'INSTITUTIONAL GOVERNANCE', ha='center', va='center',
            fontsize=12, color='white', fontweight='bold')
    ax.text(7, 1.0, 'Mediating Variable: Determines rent conversion efficiency',
            ha='center', va='center', fontsize=9, color='white')
    
    ax.annotate('', xy=(7, 2.5), xytext=(7, 3.4),
               arrowprops=dict(arrowstyle='<->', color=COLORS['primary'], lw=2.5))
    
    return save_figure(fig, 'fig1_1_conceptual_framework.png')


def create_methodological_flow():
    """Figure 1.2: Methodological Flow"""
    fig, ax = plt.subplots(figsize=(14, 7))
    ax.set_xlim(0, 14)
    ax.set_ylim(0, 8)
    ax.axis('off')
    
    ax.text(7, 7.5, 'Methodological Flow: From Data to Policy Simulations',
            ha='center', fontsize=14, fontweight='bold', color=COLORS['primary'])
    
    stages = [
        (1.5, 4.5, 'Data\nCollection', COLORS['primary']),
        (4.5, 4.5, 'Resource\nAnalysis', COLORS['secondary']),
        (7.5, 4.5, 'Shock\nModeling', COLORS['accent']),
        (10.5, 4.5, 'Governance\nAssessment', COLORS['positive']),
        (13, 4.5, 'Policy\nDesign', COLORS['highlight']),
    ]
    
    for i, (x, y, text, color) in enumerate(stages):
        rect = FancyBboxPatch((x-1.1, y-0.8), 2.2, 1.6, boxstyle="round,pad=0.05",
                              facecolor=color, alpha=0.9, edgecolor='white', linewidth=2)
        ax.add_patch(rect)
        ax.text(x, y, text, ha='center', va='center', fontsize=9, color='white', fontweight='bold')
        
        circle = plt.Circle((x-0.8, y+0.7), 0.2, color='white', alpha=0.9)
        ax.add_patch(circle)
        ax.text(x-0.8, y+0.7, str(i+1), ha='center', va='center', fontsize=9, fontweight='bold', color=color)
        
        if i < len(stages) - 1:
            ax.annotate('', xy=(stages[i+1][0]-1.2, y), xytext=(x+1.2, y),
                       arrowprops=dict(arrowstyle='->', color=COLORS['neutral'], lw=2.5))
    
    return save_figure(fig, 'fig1_2_methodological_flow.png')


def create_price_volatility():
    """Figure 2.1: Critical Minerals Price Volatility"""
    fig, ax = plt.subplots(figsize=(14, 7))
    
    years = np.arange(2010, 2025)
    np.random.seed(42)
    
    lithium = 100 * np.cumprod(1 + np.array([0.05, 0.08, -0.02, 0.15, 0.25, 0.10, -0.05, 
                                              0.20, 0.35, 0.15, -0.10, 0.40, 0.55, 0.30, -0.15]))
    cobalt = 100 * np.cumprod(1 + np.array([0.10, -0.05, 0.20, 0.15, -0.10, 0.30, 0.25, 
                                             -0.15, 0.20, -0.20, 0.15, 0.35, -0.25, 0.10, -0.10]))
    copper = 100 * np.cumprod(1 + np.array([0.15, -0.10, 0.05, -0.08, 0.12, -0.15, 0.10, 
                                             0.25, -0.05, 0.08, 0.20, 0.25, -0.12, 0.05, 0.08]))
    rare_earths = 100 * np.cumprod(1 + np.array([0.30, 0.50, -0.30, -0.20, 0.10, -0.15, 0.05, 
                                                  0.20, -0.10, -0.05, 0.15, 0.30, 0.20, 0.10, -0.05]))
    
    ax.plot(years, lithium, label='Lithium', color=COLORS['primary'], linewidth=2.5, marker='o', markersize=4)
    ax.plot(years, cobalt, label='Cobalt', color=COLORS['accent'], linewidth=2.5, marker='s', markersize=4)
    ax.plot(years, copper, label='Copper', color=COLORS['positive'], linewidth=2.5, marker='^', markersize=4)
    ax.plot(years, rare_earths, label='Rare Earths', color=COLORS['negative'], linewidth=2.5, marker='d', markersize=4)
    
    ax.axhline(y=100, color=COLORS['neutral'], linestyle='--', alpha=0.5, linewidth=1.5)
    ax.axvspan(2020, 2023, alpha=0.15, color=COLORS['negative'])
    ax.text(2021.5, 700, 'High Volatility\nPeriod', ha='center', fontsize=9, color=COLORS['negative'], fontweight='bold')
    
    ax.set_xlabel('Year', fontsize=11)
    ax.set_ylabel('Price Index (2010 = 100)', fontsize=11)
    ax.set_title('Figure 2.1. Critical Minerals Price Volatility (2010-2024)', fontsize=12, fontweight='bold', color=COLORS['primary'])
    ax.legend(loc='upper left')
    ax.set_xlim(2010, 2024)
    
    return save_figure(fig, 'fig2_1_price_volatility.png')


def create_export_dependence():
    """Figure 2.2: Resource Export Dependence"""
    fig, ax = plt.subplots(figsize=(14, 9))
    
    countries = ['DRC', 'Saudi Arabia', 'Nigeria', 'Venezuela', 'Angola', 
                 'Chile', 'Russia', 'South Africa', 'Peru', 'Australia',
                 'Indonesia', 'Canada', 'Brazil', 'China', 'Japan']
    
    dependence = [92, 85, 82, 80, 75, 78, 58, 62, 48, 65, 45, 35, 38, 12, 4]
    
    colors_bar = [COLORS['negative'] if d > 60 else COLORS['accent'] if d > 30 else COLORS['positive'] for d in dependence]
    
    y_pos = np.arange(len(countries))
    bars = ax.barh(y_pos, dependence, color=colors_bar, edgecolor='white', linewidth=0.5, height=0.7)
    
    ax.axvline(x=60, color=COLORS['negative'], linestyle='--', linewidth=2.5, label='High Vulnerability (60%)')
    ax.axvline(x=30, color=COLORS['accent'], linestyle='--', linewidth=2, label='Moderate (30%)')
    
    for bar, val in zip(bars, dependence):
        ax.text(val + 1.5, bar.get_y() + bar.get_height()/2, f'{val}%', va='center', fontsize=9, fontweight='bold')
    
    ax.set_yticks(y_pos)
    ax.set_yticklabels(countries, fontsize=10)
    ax.set_xlabel('Resource Export Dependence Ratio (%)', fontsize=11)
    ax.set_title('Figure 2.2. Resource Export Dependence by Country (2023)', fontsize=12, fontweight='bold', color=COLORS['primary'])
    ax.legend(loc='lower right')
    ax.set_xlim(0, 105)
    
    return save_figure(fig, 'fig2_2_export_dependence.png')


def create_institutional_map():
    """Figure 2.3: Institutional Architecture"""
    fig, ax = plt.subplots(figsize=(14, 10))
    ax.set_xlim(0, 14)
    ax.set_ylim(0, 12)
    ax.axis('off')
    
    ax.text(7, 11.5, 'Institutional Architecture for Resource Governance',
            ha='center', fontsize=14, fontweight='bold', color=COLORS['primary'])
    
    rect = FancyBboxPatch((4.5, 9), 5, 1.8, boxstyle="round,pad=0.1",
                          facecolor=COLORS['primary'], edgecolor='white', linewidth=3)
    ax.add_patch(rect)
    ax.text(7, 9.9, 'CENTRAL GOVERNMENT', ha='center', fontsize=12, color='white', fontweight='bold')
    
    ministries = [(2, 6.5, 'Ministry of\nFinance'), (5.5, 6.5, 'Ministry of\nMining/Energy'),
                  (9, 6.5, 'Central\nBank'), (12, 6.5, 'Ministry of\nTrade')]
    
    for x, y, text in ministries:
        rect = FancyBboxPatch((x-1.3, y-1), 2.6, 2, boxstyle="round,pad=0.05",
                              facecolor=COLORS['secondary'], edgecolor='white', linewidth=2)
        ax.add_patch(rect)
        ax.text(x, y, text, ha='center', fontsize=9, color='white', fontweight='bold')
        ax.annotate('', xy=(x, y+1), xytext=(7, 9), arrowprops=dict(arrowstyle='->', color=COLORS['neutral'], lw=1.5))
    
    agencies = [(2, 3.5, 'Revenue\nAuthority'), (5.5, 3.5, 'Geological\nSurvey'),
                (9, 3.5, 'Sovereign\nWealth Fund'), (12, 3.5, 'Export\nPromotion')]
    
    for i, (x, y, text) in enumerate(agencies):
        rect = FancyBboxPatch((x-1.3, y-1), 2.6, 2, boxstyle="round,pad=0.05",
                              facecolor=COLORS['accent'], edgecolor='white', linewidth=2)
        ax.add_patch(rect)
        ax.text(x, y, text, ha='center', fontsize=9, color='white', fontweight='bold')
        ax.annotate('', xy=(x, y+1), xytext=(ministries[i][0], ministries[i][1]-1),
                   arrowprops=dict(arrowstyle='->', color=COLORS['neutral'], lw=1.5))
    
    return save_figure(fig, 'fig2_3_institutional_map.png')


def create_dutch_disease():
    """Figure 4.1: Dutch Disease Transmission"""
    fig, ax = plt.subplots(figsize=(16, 10))
    ax.set_xlim(0, 16)
    ax.set_ylim(0, 11)
    ax.axis('off')
    
    ax.text(8, 10.5, 'Dutch Disease Transmission Mechanism',
            ha='center', fontsize=14, fontweight='bold', color=COLORS['primary'])
    
    stages = [
        (2, 8, 'Stage 1:\nResource Boom', COLORS['positive']),
        (6, 8, 'Stage 2:\nCapital Inflows', COLORS['secondary']),
        (10, 8, 'Stage 3:\nCurrency Appreciation', COLORS['accent']),
        (14, 8, 'Stage 4:\nDeindustrialization', COLORS['negative']),
    ]
    
    for i, (x, y, text, color) in enumerate(stages):
        rect = FancyBboxPatch((x-1.8, y-1.2), 3.6, 2.4, boxstyle="round,pad=0.1",
                              facecolor=color, alpha=0.9, edgecolor='white', linewidth=2)
        ax.add_patch(rect)
        ax.text(x, y, text, ha='center', fontsize=10, color='white', fontweight='bold')
        
        if i < len(stages) - 1:
            ax.annotate('', xy=(stages[i+1][0]-1.9, y), xytext=(x+1.9, y),
                       arrowprops=dict(arrowstyle='->', color=COLORS['neutral'], lw=3))
    
    gov_rect = FancyBboxPatch((0.5, 0.5), 7, 3.5, boxstyle="round,pad=0.1",
                              facecolor=COLORS['primary'], alpha=0.95, edgecolor='white', linewidth=3)
    ax.add_patch(gov_rect)
    ax.text(4, 3.3, 'GOVERNANCE INTERVENTION', ha='center', fontsize=11, color='white', fontweight='bold')
    ax.text(4, 2, '• Sovereign Wealth Fund\n• FX Sterilization\n• Fiscal Rules\n• Diversification Policy',
            ha='center', fontsize=9, color='white')
    
    return save_figure(fig, 'fig4_1_dutch_disease.png')


def create_governance_threshold():
    """Figure 4.2: Governance Threshold Chart"""
    fig, ax = plt.subplots(figsize=(14, 9))
    
    governance_score = np.linspace(0, 100, 500)
    threshold = 48.3
    productivity = 100 / (1 + np.exp(-0.08 * (governance_score - threshold)))
    rent_capture = 100 - productivity
    
    ax.plot(governance_score, productivity, color=COLORS['positive'], linewidth=3, 
            label='Productive Investment (% of rents)')
    ax.plot(governance_score, rent_capture, color=COLORS['negative'], linewidth=3, 
            linestyle='--', label='Rent Capture (% of rents)')
    
    ax.axvspan(40, 60, alpha=0.2, color=COLORS['highlight'], label='Threshold Zone')
    ax.axvline(x=threshold, color=COLORS['primary'], linestyle=':', linewidth=3, 
               label=f'Critical Threshold ({threshold})')
    
    ax.fill_between(governance_score, 0, productivity, alpha=0.15, color=COLORS['positive'])
    
    ax.annotate('RESOURCE CURSE\nZONE', xy=(20, 20), fontsize=11, ha='center', color=COLORS['negative'], fontweight='bold')
    ax.annotate('PRODUCTIVE\nZONE', xy=(80, 80), fontsize=11, ha='center', color=COLORS['positive'], fontweight='bold')
    
    countries = [('Norway', 89, 85), ('Chile', 65, 70), ('Nigeria', 38, 35), ('DRC', 25, 20)]
    for name, gov, prod in countries:
        color = COLORS['positive'] if gov > 50 else COLORS['negative']
        ax.scatter(gov, prod, s=150, c=[color], edgecolor='white', linewidth=2, zorder=5)
        ax.annotate(name, (gov, prod), xytext=(5, 5), textcoords='offset points', fontsize=9, fontweight='bold')
    
    ax.set_xlabel('Institutional Quality Index (0-100)', fontsize=11)
    ax.set_ylabel('Allocation of Resource Rents (%)', fontsize=11)
    ax.set_title('Figure 4.2. Governance Threshold: When Institutions Convert Rents into Productivity', 
                 fontsize=12, fontweight='bold', color=COLORS['primary'])
    ax.legend(loc='center right')
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 105)
    
    return save_figure(fig, 'fig4_2_governance_threshold.png')


def create_country_typology():
    """Figure 4.3: Country Typology Quadrant"""
    fig, ax = plt.subplots(figsize=(14, 11))
    
    ax.axhline(y=50, color=COLORS['neutral'], linestyle='-', linewidth=1.5, alpha=0.7)
    ax.axvline(x=50, color=COLORS['neutral'], linestyle='-', linewidth=1.5, alpha=0.7)
    
    ax.fill_between([50, 100], 50, 100, alpha=0.1, color=COLORS['positive'])
    ax.fill_between([0, 50], 50, 100, alpha=0.1, color=COLORS['secondary'])
    ax.fill_between([50, 100], 0, 50, alpha=0.1, color=COLORS['negative'])
    ax.fill_between([0, 50], 0, 50, alpha=0.1, color=COLORS['accent'])
    
    countries = {
        'Norway': (85, 92, COLORS['positive']), 'Australia': (78, 82, COLORS['positive']),
        'Canada': (72, 85, COLORS['positive']), 'Chile': (75, 65, COLORS['positive']),
        'DRC': (88, 25, COLORS['negative']), 'Nigeria': (82, 35, COLORS['negative']),
        'Venezuela': (80, 28, COLORS['negative']), 'Angola': (75, 30, COLORS['negative']),
        'Japan': (20, 88, COLORS['secondary']), 'Germany': (25, 85, COLORS['secondary']),
        'Singapore': (15, 95, COLORS['secondary']), 'Haiti': (12, 22, COLORS['accent']),
        'Niger': (25, 28, COLORS['accent']),
    }
    
    for name, (x, y, color) in countries.items():
        ax.scatter(x, y, s=200, c=[color], alpha=0.85, edgecolor='white', linewidth=2)
        ax.annotate(name, (x, y), xytext=(6, 6), textcoords='offset points', fontsize=9, fontweight='bold')
    
    ax.text(25, 95, 'TYPE IV: Resource-Poor/High Capacity', fontsize=10, fontweight='bold', color=COLORS['secondary'], ha='center')
    ax.text(75, 95, 'TYPE I: Resource-Rich/High Capacity', fontsize=10, fontweight='bold', color=COLORS['positive'], ha='center')
    ax.text(75, 5, 'TYPE II: Resource-Rich/Low Capacity', fontsize=10, fontweight='bold', color=COLORS['negative'], ha='center')
    ax.text(25, 5, 'TYPE III: Resource-Poor/Low Capacity', fontsize=10, fontweight='bold', color=COLORS['accent'], ha='center')
    
    ax.set_xlabel('Resource Endowment Index (0-100)', fontsize=11)
    ax.set_ylabel('Institutional Capacity Index (0-100)', fontsize=11)
    ax.set_title('Figure 4.3. Country Typology Matrix', fontsize=12, fontweight='bold', color=COLORS['primary'])
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    
    return save_figure(fig, 'fig4_3_country_typology.png')


def create_volatility_stress():
    """Figure 4.4: Volatility Stress Metric"""
    fig, ax = plt.subplots(figsize=(14, 9))
    
    countries = ['DRC', 'Nigeria', 'Venezuela', 'Angola', 'Iraq', 'Saudi Arabia', 
                 'Russia', 'Chile', 'Zambia', 'Indonesia', 'Australia', 'Norway', 'Canada', 'Japan']
    volatility = [0.42, 0.38, 0.40, 0.35, 0.32, 0.28, 0.25, 0.22, 0.24, 0.18, 0.15, 0.12, 0.10, 0.05]
    
    colors_bar = [COLORS['negative'] if v > 0.30 else COLORS['accent'] if v > 0.20 else COLORS['positive'] for v in volatility]
    
    y_pos = np.arange(len(countries))
    bars = ax.barh(y_pos, volatility, color=colors_bar, edgecolor='white', linewidth=0.5, height=0.7)
    
    ax.axvline(x=0.30, color=COLORS['negative'], linestyle='--', linewidth=2.5, label='Critical (0.30)')
    ax.axvline(x=0.20, color=COLORS['accent'], linestyle='--', linewidth=2, label='Moderate (0.20)')
    
    for bar, val in zip(bars, volatility):
        ax.text(val + 0.01, bar.get_y() + bar.get_height()/2, f'{val:.2f}', va='center', fontsize=9)
    
    ax.set_yticks(y_pos)
    ax.set_yticklabels(countries, fontsize=10)
    ax.set_xlabel('Volatility Stress Metric', fontsize=11)
    ax.set_title('Figure 4.4. Volatility Stress Metric by Country', fontsize=12, fontweight='bold', color=COLORS['primary'])
    ax.legend(loc='lower right')
    ax.set_xlim(0, 0.50)
    
    return save_figure(fig, 'fig4_4_volatility_stress.png')


def create_trade_shock_simulation():
    """Figure 4.5: Trade Balance Shock Simulation"""
    fig, axes = plt.subplots(1, 3, figsize=(16, 6))
    
    months = np.arange(1, 25)
    np.random.seed(42)
    
    # Panel A: FX Reserves
    ax1 = axes[0]
    reserves_high = np.clip(100 - np.cumsum(np.abs(np.random.normal(0.8, 0.1, 24))), 0, 100)
    reserves_med = np.clip(100 - np.cumsum(np.abs(np.random.normal(0.4, 0.05, 24))), 0, 100)
    reserves_low = np.clip(100 - np.cumsum(np.abs(np.random.normal(0.15, 0.02, 24))), 0, 100)
    
    ax1.plot(months, reserves_high, color=COLORS['negative'], linewidth=2.5, label='High Dependence')
    ax1.plot(months, reserves_med, color=COLORS['accent'], linewidth=2.5, label='Medium')
    ax1.plot(months, reserves_low, color=COLORS['positive'], linewidth=2.5, label='Low')
    ax1.axhline(y=30, color=COLORS['negative'], linestyle='--', alpha=0.7)
    ax1.set_xlabel('Months Since Shock')
    ax1.set_ylabel('FX Reserves (% of pre-shock)')
    ax1.set_title('A. FX Reserve Drawdown', fontweight='bold')
    ax1.legend(fontsize=8)
    
    # Panel B: Inflation
    ax2 = axes[1]
    inflation_high = 2 + np.cumsum(np.abs(np.random.normal(0.35, 0.08, 24)))
    inflation_med = 2 + np.cumsum(np.abs(np.random.normal(0.18, 0.04, 24)))
    inflation_low = 2 + np.cumsum(np.abs(np.random.normal(0.07, 0.02, 24)))
    
    ax2.plot(months, inflation_high, color=COLORS['negative'], linewidth=2.5, label='High Dependence')
    ax2.plot(months, inflation_med, color=COLORS['accent'], linewidth=2.5, label='Medium')
    ax2.plot(months, inflation_low, color=COLORS['positive'], linewidth=2.5, label='Low')
    ax2.axhline(y=10, color=COLORS['negative'], linestyle='--', alpha=0.7)
    ax2.set_xlabel('Months Since Shock')
    ax2.set_ylabel('Inflation Rate (%)')
    ax2.set_title('B. Inflation Transmission', fontweight='bold')
    ax2.legend(fontsize=8)
    
    # Panel C: GDP
    ax3 = axes[2]
    gdp_high = np.clip(100 - np.cumsum(np.abs(np.random.normal(0.28, 0.06, 24))), 70, 100)
    gdp_med = np.clip(100 - np.cumsum(np.abs(np.random.normal(0.12, 0.03, 24))), 85, 100)
    gdp_low = np.clip(100 - np.cumsum(np.abs(np.random.normal(0.04, 0.01, 24))), 93, 100)
    
    ax3.plot(months, gdp_high, color=COLORS['negative'], linewidth=2.5, label='High Dependence')
    ax3.plot(months, gdp_med, color=COLORS['accent'], linewidth=2.5, label='Medium')
    ax3.plot(months, gdp_low, color=COLORS['positive'], linewidth=2.5, label='Low')
    ax3.axhline(y=95, color=COLORS['accent'], linestyle='--', alpha=0.7)
    ax3.set_xlabel('Months Since Shock')
    ax3.set_ylabel('GDP Index (Pre-shock = 100)')
    ax3.set_title('C. GDP Impact', fontweight='bold')
    ax3.legend(fontsize=8)
    
    fig.suptitle('Figure 4.5. Trade Balance Shock Simulation: +30% Import Cost', fontsize=13, fontweight='bold')
    plt.tight_layout()
    
    return save_figure(fig, 'fig4_5_trade_shock_simulation.png')


def create_swf_design():
    """Figure 5.1: Sovereign Wealth Fund Design"""
    fig, ax = plt.subplots(figsize=(14, 10))
    ax.set_xlim(0, 14)
    ax.set_ylim(0, 11)
    ax.axis('off')
    
    ax.text(7, 10.5, 'Sovereign Wealth Fund Design Parameters',
            ha='center', fontsize=14, fontweight='bold', color=COLORS['primary'])
    
    main_rect = FancyBboxPatch((3, 6), 8, 3.5, boxstyle="round,pad=0.15",
                               facecolor=COLORS['primary'], edgecolor='white', linewidth=3)
    ax.add_patch(main_rect)
    ax.text(7, 8.5, 'SOVEREIGN WEALTH FUND', ha='center', fontsize=16, color='white', fontweight='bold')
    ax.text(7, 7, 'Stabilization & Intergenerational Savings', ha='center', fontsize=11, color='white')
    
    pillars = [
        (2, 2.5, 'DEPOSIT RULES', COLORS['positive'], 'Reference price rule\nBaseline threshold\nExcess profit tax'),
        (7, 2.5, 'WITHDRAWAL RULES', COLORS['accent'], 'Structural balance\nPrice floor trigger\nCap at 4% NAV'),
        (12, 2.5, 'FX STERILIZATION', COLORS['secondary'], 'Offshore investment\nBond issuance\nReserve requirements'),
    ]
    
    for x, y, title, color, details in pillars:
        rect = FancyBboxPatch((x-2, y-1.8), 4, 3.6, boxstyle="round,pad=0.1",
                              facecolor=color, alpha=0.9, edgecolor='white', linewidth=2)
        ax.add_patch(rect)
        ax.text(x, y+1, title, ha='center', fontsize=11, color='white', fontweight='bold')
        ax.text(x, y-0.5, details, ha='center', fontsize=8, color='white')
        ax.annotate('', xy=(x, 6), xytext=(x, y+1.8),
                   arrowprops=dict(arrowstyle='->', color=COLORS['neutral'], lw=2.5))
    
    return save_figure(fig, 'fig5_1_swf_design.png')


def create_implementation_roadmap():
    """Figure 5.2: Implementation Roadmap"""
    fig, ax = plt.subplots(figsize=(16, 8))
    
    workstreams = ['Legal Framework', 'SWF Structure', 'Deposit Rules', 'Investment Policy',
                   'FX Operations', 'Risk Management', 'Capacity Building']
    
    phase_colors = [COLORS['secondary'], COLORS['primary'], COLORS['positive']]
    phase_positions = [0, 6, 24]
    phase_durations = [6, 18, 24]
    
    for i, (pos, dur) in enumerate(zip(phase_positions, phase_durations)):
        ax.barh(len(workstreams), dur, left=pos, height=1, color=phase_colors[i], alpha=0.8, edgecolor='white')
        ax.text(pos + dur/2, len(workstreams), f'Phase {i+1}', ha='center', va='center', fontsize=9, color='white', fontweight='bold')
    
    for i, name in enumerate(workstreams):
        ax.text(-1, i, name, ha='right', va='center', fontsize=9)
        for j in range(3):
            if j < 2 or i in [2, 3, 4, 5, 6]:
                ax.barh(i, phase_durations[j] if j < 2 else phase_durations[2], 
                        left=phase_positions[j], height=0.5, color=phase_colors[j], alpha=0.6)
    
    for pos in [6, 24]:
        ax.axvline(x=pos, color=COLORS['neutral'], linestyle=':', alpha=0.7)
    
    ax.set_xlim(-4, 52)
    ax.set_ylim(-1, len(workstreams)+1.5)
    ax.set_xlabel('Months from Start', fontsize=11)
    ax.set_title('Figure 5.2. Implementation Roadmap', fontsize=12, fontweight='bold', color=COLORS['primary'])
    ax.set_yticks([])
    
    return save_figure(fig, 'fig5_2_implementation_roadmap.png')


def create_results_framework():
    """Figure 6.1: Results Framework"""
    fig, ax = plt.subplots(figsize=(16, 9))
    ax.set_xlim(0, 16)
    ax.set_ylim(0, 11)
    ax.axis('off')
    
    ax.text(8, 10.5, 'Results Chain: From Inputs to Impact',
            ha='center', fontsize=14, fontweight='bold', color=COLORS['primary'])
    
    levels = [
        ('IMPACT', 8.5, COLORS['primary'], 'Sustainable Growth & Governance'),
        ('OUTCOMES', 6.5, COLORS['secondary'], 'Stabilization | Diversification'),
        ('OUTPUTS', 4.5, COLORS['accent'], 'SWF | Policies | Capacity'),
        ('ACTIVITIES', 2.5, COLORS['neutral'], 'Legal Reform | Training | Systems'),
        ('INPUTS', 0.8, COLORS['positive'], 'Funding | Technical Assistance'),
    ]
    
    for i, (label, y, color, details) in enumerate(levels):
        width = 14 - i * 1.5
        x_start = 1 + i * 0.75
        rect = FancyBboxPatch((x_start, y-0.6), width, 1.5, boxstyle="round,pad=0.05",
                              facecolor=color, alpha=0.85, edgecolor='white', linewidth=2)
        ax.add_patch(rect)
        ax.text(8, y, f'{label}: {details}', ha='center', fontsize=10, color='white', fontweight='bold')
        
        if i < len(levels) - 1:
            ax.annotate('', xy=(8, levels[i+1][1]+0.6), xytext=(8, y-0.6),
                       arrowprops=dict(arrowstyle='->', color=COLORS['neutral'], lw=2.5))
    
    return save_figure(fig, 'fig6_1_results_framework.png')


def create_resource_balance_sheet():
    """Figure 6.2: Resource Balance Sheet"""
    fig, ax = plt.subplots(figsize=(14, 8))
    
    categories = ['Copper', 'Lithium', 'Cobalt', 'Rare Earths', 'Water']
    stocks = [450, 280, 120, 85, 500]
    flows = [85, 45, 18, 12, 120]
    fiscal = [25, 12, 5, 3, 15]
    
    x = np.arange(len(categories))
    width = 0.25
    
    ax.bar(x - width, stocks, width, label='Stock (Reserves)', color=COLORS['primary'])
    ax.bar(x, flows, width, label='Flow (Annual)', color=COLORS['secondary'])
    ax.bar(x + width, fiscal, width, label='Fiscal Capture', color=COLORS['accent'])
    
    ax.set_ylabel('Value (Billion USD)', fontsize=11)
    ax.set_xlabel('Resource Category', fontsize=11)
    ax.set_title('Figure 6.2. Macro Resource Balance Sheet', fontsize=12, fontweight='bold', color=COLORS['primary'])
    ax.set_xticks(x)
    ax.set_xticklabels(categories)
    ax.legend()
    
    return save_figure(fig, 'fig6_2_resource_balance_sheet.png')


def create_sensitivity_analysis():
    """Figure A.1: Sensitivity Analysis"""
    fig, axes = plt.subplots(1, 2, figsize=(16, 7))
    
    # Panel A: Break-even
    ax1 = axes[0]
    demand = np.linspace(50, 200, 100)
    profit_a = 0.8 * demand - (50 + 0.3 * demand)
    profit_b = 0.5 * demand - (20 + 0.1 * demand)
    
    ax1.plot(demand, profit_a, color=COLORS['primary'], linewidth=2.5, label='Option A: Downstream')
    ax1.plot(demand, profit_b, color=COLORS['accent'], linewidth=2.5, label='Option B: Raw Export')
    ax1.axhline(y=0, color=COLORS['neutral'], linestyle='--', alpha=0.7)
    ax1.axvline(x=100, color=COLORS['negative'], linestyle=':', linewidth=2.5)
    ax1.set_xlabel('Demand Volume')
    ax1.set_ylabel('Net Benefit (Million USD)')
    ax1.set_title('A. Break-even Analysis', fontweight='bold')
    ax1.legend(fontsize=8)
    
    # Panel B: Scenario test
    ax2 = axes[1]
    scenarios = ['Base', 'Price -20%', 'Price +30%', 'Demand -15%', 'Demand +25%', 'Stress']
    npv_high = [100, 75, 135, 80, 125, 55]
    npv_low = [60, 35, 85, 40, 75, 15]
    
    x = np.arange(len(scenarios))
    ax2.bar(x - 0.175, npv_high, 0.35, label='High Capacity', color=COLORS['positive'])
    ax2.bar(x + 0.175, npv_low, 0.35, label='Low Capacity', color=COLORS['negative'])
    ax2.axhline(y=50, color=COLORS['accent'], linestyle='--')
    ax2.set_ylabel('NPV (Million USD)')
    ax2.set_title('B. Scenario Stress Test', fontweight='bold')
    ax2.set_xticks(x)
    ax2.set_xticklabels(scenarios, rotation=45, ha='right')
    ax2.legend(fontsize=8)
    
    fig.suptitle('Figure A.1. Sensitivity Analysis', fontsize=13, fontweight='bold')
    plt.tight_layout()
    
    return save_figure(fig, 'fig_a1_sensitivity_analysis.png')


def create_supply_chain():
    """Figure A.2: Supply Chain Map"""
    fig, ax = plt.subplots(figsize=(16, 10))
    ax.set_xlim(0, 16)
    ax.set_ylim(0, 11)
    ax.axis('off')
    
    ax.text(8, 10.5, 'Global Critical Mineral Supply Chain',
            ha='center', fontsize=14, fontweight='bold', color=COLORS['primary'])
    
    stages = [
        (2, 6, 'PRODUCERS', COLORS['negative'], 'DRC, Chile, Australia'),
        (6, 6, 'PROCESSING', COLORS['accent'], 'China (60%)'),
        (10, 6, 'MANUFACTURING', COLORS['secondary'], 'China, Japan, EU'),
        (14, 6, 'CONSUMERS', COLORS['positive'], 'US, EU, China'),
    ]
    
    for x, y, title, color, details in stages:
        rect = FancyBboxPatch((x-1.5, y-1.3), 3, 2.6, boxstyle="round,pad=0.1",
                              facecolor=color, alpha=0.85, edgecolor='white', linewidth=2)
        ax.add_patch(rect)
        ax.text(x, y+0.5, title, ha='center', fontsize=10, color='white', fontweight='bold')
        ax.text(x, y-0.5, details, ha='center', fontsize=8, color='white')
    
    for i in range(len(stages)-1):
        ax.annotate('', xy=(stages[i+1][0]-1.6, 6), xytext=(stages[i][0]+1.6, 6),
                   arrowprops=dict(arrowstyle='->', color=COLORS['neutral'], lw=3))
    
    return save_figure(fig, 'fig_a2_supply_chain.png')


def create_substitution_potential():
    """Figure A.3: Substitution Potential"""
    fig, ax = plt.subplots(figsize=(14, 8))
    
    minerals = ['Lithium', 'Cobalt', 'Rare Earths', 'Copper', 'Nickel', 'Graphite']
    technical = [25, 45, 35, 20, 55, 40]
    economic = [15, 30, 20, 10, 40, 25]
    
    x = np.arange(len(minerals))
    width = 0.35
    
    ax.bar(x - width/2, technical, width, label='Technical Feasibility', color=COLORS['primary'])
    ax.bar(x + width/2, economic, width, label='Economic Viability', color=COLORS['secondary'])
    ax.axhline(y=40, color=COLORS['positive'], linestyle='--', label='Decoupling Threshold')
    
    ax.set_ylabel('Index (0-100)', fontsize=11)
    ax.set_xlabel('Critical Mineral', fontsize=11)
    ax.set_title('Figure A.3. Substitution Potential by Critical Mineral', fontsize=12, fontweight='bold', color=COLORS['primary'])
    ax.set_xticks(x)
    ax.set_xticklabels(minerals)
    ax.legend()
    
    return save_figure(fig, 'fig_a3_substitution_potential.png')


def create_water_stress():
    """Figure A.4: Water Stress"""
    fig, axes = plt.subplots(1, 2, figsize=(16, 7))
    
    # Panel A
    ax1 = axes[0]
    regions = ['MENA', 'South Asia', 'Central Asia', 'East Asia', 'Sub-Saharan Africa', 'Latin America', 'Europe', 'N. America']
    stress = [85, 78, 72, 45, 55, 35, 25, 20]
    
    colors_bar = [COLORS['negative'] if s > 70 else COLORS['accent'] if s > 40 else COLORS['positive'] for s in stress]
    ax1.barh(regions, stress, color=colors_bar)
    ax1.axvline(x=70, color=COLORS['negative'], linestyle='--', linewidth=2, label='Critical')
    ax1.set_xlabel('Water Stress Index')
    ax1.set_title('A. Regional Water Stress', fontweight='bold')
    ax1.legend(fontsize=8)
    
    # Panel B
    ax2 = axes[1]
    scarcity = np.linspace(0, 100, 100)
    gdp_impact = -0.5 * (scarcity / 100) ** 2 - 0.3 * (scarcity / 100)
    
    ax2.plot(scarcity, gdp_impact, color=COLORS['primary'], linewidth=3)
    ax2.fill_between(scarcity, gdp_impact, 0, alpha=0.2, color=COLORS['negative'])
    ax2.axhline(y=-0.2, color=COLORS['accent'], linestyle='--', label='Moderate Impact')
    ax2.axhline(y=-0.5, color=COLORS['negative'], linestyle='--', label='Severe Impact')
    ax2.set_xlabel('Water Scarcity Index')
    ax2.set_ylabel('GDP Growth Impact (pp)')
    ax2.set_title('B. Water-GDP Relationship', fontweight='bold')
    ax2.legend(fontsize=8)
    
    fig.suptitle('Figure A.4. Water Stress as Macro-Economic Constraint', fontsize=13, fontweight='bold')
    plt.tight_layout()
    
    return save_figure(fig, 'fig_a4_water_stress.png')


def create_risk_heatmap():
    """Figure A.5: Risk Heat Map"""
    fig, ax = plt.subplots(figsize=(14, 9))
    
    risks = ['Price Shock', 'Supply Disruption', 'Currency Crisis', 'Fiscal Collapse',
             'Social Unrest', 'Regulatory Change', 'Technology Disruption', 'Geopolitical Conflict']
    
    likelihood = [4, 3, 3, 2, 3, 2, 2, 3]
    impact = [5, 5, 4, 5, 4, 3, 4, 5]
    risk_scores = [l * i for l, i in zip(likelihood, impact)]
    
    colors_risk = [COLORS['negative'] if s >= 16 else COLORS['accent'] if s >= 9 else COLORS['positive'] for s in risk_scores]
    
    y_pos = np.arange(len(risks))
    bars = ax.barh(y_pos, risk_scores, color=colors_risk, edgecolor='white')
    
    ax.axvline(x=16, color=COLORS['negative'], linestyle='--', linewidth=2.5, label='Critical')
    ax.axvline(x=9, color=COLORS['accent'], linestyle='--', linewidth=2, label='Moderate')
    
    for bar, score in zip(bars, risk_scores):
        ax.text(score + 0.5, bar.get_y() + bar.get_height()/2, f'{score}', va='center', fontsize=9)
    
    ax.set_yticks(y_pos)
    ax.set_yticklabels(risks, fontsize=10)
    ax.set_xlabel('Risk Score (Likelihood × Impact)', fontsize=11)
    ax.set_title('Figure A.5. Risk Register: Critical Resource Governance Risks', fontsize=12, fontweight='bold', color=COLORS['primary'])
    ax.legend(loc='lower right')
    ax.set_xlim(0, 25)
    
    return save_figure(fig, 'fig_a5_risk_heatmap.png')


# =============================================================================
# MAIN EXECUTION
# =============================================================================

def main():
    print("=" * 70)
    print("CRITICAL RESOURCES - VISUALIZATION SUITE")
    print("=" * 70)
    print(f"\nOutput directory: {os.path.abspath(OUTPUT_DIR)}")
    print("-" * 70)
    
    figures = [
        ("Conceptual Framework", create_conceptual_framework),
        ("Methodological Flow", create_methodological_flow),
        ("Price Volatility", create_price_volatility),
        ("Export Dependence", create_export_dependence),
        ("Institutional Map", create_institutional_map),
        ("Dutch Disease", create_dutch_disease),
        ("Governance Threshold", create_governance_threshold),
        ("Country Typology", create_country_typology),
        ("Volatility Stress", create_volatility_stress),
        ("Trade Shock Simulation", create_trade_shock_simulation),
        ("SWF Design", create_swf_design),
        ("Implementation Roadmap", create_implementation_roadmap),
        ("Results Framework", create_results_framework),
        ("Resource Balance Sheet", create_resource_balance_sheet),
        ("Sensitivity Analysis", create_sensitivity_analysis),
        ("Supply Chain", create_supply_chain),
        ("Substitution Potential", create_substitution_potential),
        ("Water Stress", create_water_stress),
        ("Risk Heatmap", create_risk_heatmap),
    ]
    
    success = 0
    for name, func in figures:
        try:
            func()
            success += 1
        except Exception as e:
            print(f"Error: {name} - {e}")
    
    print("-" * 70)
    print(f"\nComplete: {success}/{len(figures)} figures generated")
    print("=" * 70)


if __name__ == "__main__":
    main()
