# Critical Resources as Macro Variables - Visualization Code

## Overview

This folder contains the complete Python source code for generating all figures, charts, and visualizations used in the CEDX Research Report "Critical Resources as Macro Variables" (RR-CEDX-2025-003).

## Requirements

```bash
pip install matplotlib numpy
```

## Usage

```bash
python generate_all_visualizations.py
```

This will generate 19 professional-quality figures in the `./figures/` subdirectory.

## Figure List

| Figure | Description |
|--------|-------------|
| fig1_1_conceptual_framework.png | Conceptual Framework: Resources as Macro Production Constraints |
| fig1_2_methodological_flow.png | Methodological Flow Diagram |
| fig2_1_price_volatility.png | Critical Minerals Price Volatility (2010-2024) |
| fig2_2_export_dependence.png | Resource Export Dependence by Country |
| fig2_3_institutional_map.png | Institutional Architecture for Resource Governance |
| fig4_1_dutch_disease.png | Dutch Disease Transmission Mechanism |
| fig4_2_governance_threshold.png | Governance Threshold Chart |
| fig4_3_country_typology.png | Country Typology Quadrant Matrix |
| fig4_4_volatility_stress.png | Volatility Stress Metric by Country |
| fig4_5_trade_shock_simulation.png | Trade Balance Shock Simulation |
| fig5_1_swf_design.png | Sovereign Wealth Fund Design Parameters |
| fig5_2_implementation_roadmap.png | Implementation Roadmap |
| fig6_1_results_framework.png | Results Chain Framework |
| fig6_2_resource_balance_sheet.png | Macro Resource Balance Sheet |
| fig_a1_sensitivity_analysis.png | Sensitivity Analysis and Scenario Testing |
| fig_a2_supply_chain.png | Global Critical Mineral Supply Chain |
| fig_a3_substitution_potential.png | Substitution Potential by Critical Mineral |
| fig_a4_water_stress.png | Water Stress as Macro-Economic Constraint |
| fig_a5_risk_heatmap.png | Risk Register Heat Map |

## Color Palette

The visualizations use a professional "Ink & Zen" color palette:

- **Primary (Deep Navy)**: #1A365D
- **Secondary (Medium Blue)**: #2B6CB0
- **Accent (Terra Cotta)**: #C05621
- **Positive (Forest Green)**: #276749
- **Negative (Deep Red)**: #C53030
- **Neutral (Gray)**: #4A5568
- **Highlight (Gold)**: #D69E2E

## Customization

To modify the figures:

1. Edit the relevant function in `generate_all_visualizations.py`
2. Adjust parameters, colors, data, or styling as needed
3. Run the script to regenerate all figures

## Data Sources

The visualizations use simulated data based on:
- World Bank WDI
- IMF GFS/IFS
- USGS Mineral Commodity Summaries
- Bloomberg/LME commodity prices
- CEDX proprietary Governance Capacity Index

## License

© 2025 Centre for Economic Development and Execution (CEDX)
