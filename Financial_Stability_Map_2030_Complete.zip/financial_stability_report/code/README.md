# Visualization Code

## Overview
This folder contains Python code for generating all visualizations used in the Financial Stability Map of 2030 report.

## Files

### generate_all_visualizations.py
Complete Python script that generates all 18 figures used in the report.

**Output:** All figures saved to `../figures/` directory

**Usage:**
```bash
python generate_all_visualizations.py
```

### generate_report.py
Script that generates the complete DOCX report with embedded figures.

**Output:** `../Financial_Stability_Map_2030_Report.docx`

**Usage:**
```bash
python generate_report.py
```

## Requirements
```bash
pip install matplotlib numpy pandas docx
```

## Color Palette
The visualizations use a professional Financial Stability theme:
- Primary (Navy): #0A2342
- Secondary (Royal Blue): #1E5AA8
- Accent (Orange): #E85D04
- Positive (Green): #0A8754
- Negative (Crimson): #C41E3A
- Neutral (Gray): #5C6670
- Shadow (Brown): #8B4513
- Sovereign (Purple): #4A0E4E
- NBFI (Teal): #006D77

## Customization
To modify figures:
1. Edit the relevant function in `generate_all_visualizations.py`
2. Run the script to regenerate figures
3. To update the report, run `generate_report.py`

## Figure List
1. Global Risk Regime Overview
2. Interest Rate Trajectory and Duration Risk
3. Financial Contagion Network Diagram
4. Sovereign-Bank Nexus Analysis
5. NBFI Metrics
6. Stress Scenario Framework
7. Loss Distribution
8. FX Mismatch Analysis
9. Financial Stability Map
10. Composite Risk Index
11. Early Warning Dashboard
12. USD Dominance Analysis
13. AI-Driven Finance Risks
14. Macroprudential Playbook
15. NBFI Supervision Blueprint
16. IFI Technical Assistance Menu
17. Historical Crisis Comparison
18. Regional Vulnerability Heat Map
