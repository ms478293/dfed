#!/usr/bin/env python3
"""
=============================================================================
THE FINANCIAL STABILITY MAP OF 2030 - VISUALIZATION SUITE
=============================================================================
Complete Python code for generating all figures, charts, tables, and 
visualizations for the CEDX Research Report on Financial Stability.

Report: RR-CEDX-2025-004
Date: January 2025

Requirements:
    pip install matplotlib numpy pandas networkx

Usage:
    python generate_all_visualizations.py
    
Output:
    All figures saved to ../figures/ directory
=============================================================================
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, Circle, FancyArrowPatch
from matplotlib.collections import PatchCollection
import matplotlib.patheffects as path_effects
import numpy as np
import os
import warnings
warnings.filterwarnings('ignore')

# =============================================================================
# CONFIGURATION AND STYLING
# =============================================================================

plt.rcParams.update({
    'font.family': 'DejaVu Sans',
    'font.size': 10,
    'axes.titlesize': 12,
    'axes.labelsize': 10,
    'xtick.labelsize': 9,
    'ytick.labelsize': 9,
    'legend.fontsize': 9,
    'figure.titlesize': 14,
    'axes.spines.top': False,
    'axes.spines.right': False,
    'axes.grid': True,
    'grid.alpha': 0.3,
    'grid.linestyle': '--',
    'figure.dpi': 300,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight',
    'savefig.facecolor': 'white',
    'savefig.edgecolor': 'none',
})

# Professional color palette - Financial Stability Theme
COLORS = {
    'primary': '#0A2342',       # Deep Navy (Stability)
    'secondary': '#1E5AA8',     # Royal Blue (Banks)
    'accent': '#E85D04',        # Orange (Risk/Alert)
    'positive': '#0A8754',      # Green (Safe)
    'negative': '#C41E3A',      # Crimson (Danger)
    'neutral': '#5C6670',       # Gray (Neutral)
    'light_bg': '#F5F7FA',      # Light Background
    'highlight': '#FFB627',     # Gold (Warning)
    'shadow': '#8B4513',        # Shadow Banking
    'sovereign': '#4A0E4E',     # Purple (Sovereign)
    'nbfi': '#006D77',          # Teal (NBFI)
}

OUTPUT_DIR = '../figures'
os.makedirs(OUTPUT_DIR, exist_ok=True)

def save_figure(fig, filename):
    """Save figure with standard settings"""
    filepath = os.path.join(OUTPUT_DIR, filename)
    fig.savefig(filepath, facecolor='white', edgecolor='none')
    plt.close(fig)
    print(f"✓ Saved: {filepath}")
    return filepath


# =============================================================================
# FIGURE 1.1: GLOBAL RISK REGIME OVERVIEW
# =============================================================================

def create_global_risk_regime():
    """
    Figure 1.1: Global Risk Regime Overview
    
    Shows the five pillars of systemic risk in the current environment.
    """
    fig, ax = plt.subplots(figsize=(16, 10))
    ax.set_xlim(0, 16)
    ax.set_ylim(0, 12)
    ax.axis('off')
    
    # Title
    ax.text(8, 11.5, 'Global Risk Regime: Five Pillars of Systemic Vulnerability',
            ha='center', fontsize=16, fontweight='bold', color=COLORS['primary'])
    ax.text(8, 10.8, 'Financial Stability Map of 2030 Framework',
            ha='center', fontsize=11, color=COLORS['neutral'])
    
    # Central risk hub
    central_circle = Circle((8, 5.5), 1.5, facecolor=COLORS['negative'], 
                            edgecolor='white', linewidth=3, alpha=0.9)
    ax.add_patch(central_circle)
    ax.text(8, 5.5, 'SYSTEMIC\nRISK\nHUB', ha='center', va='center',
            fontsize=11, color='white', fontweight='bold')
    
    # Five risk pillars
    pillars = [
        (3, 8, 'HIGH\nINTEREST\nRATES', COLORS['accent'], 
         ['Policy rates at 15-year highs', 'Duration losses embedded', 'Refinancing wall 2025-2027']),
        (13, 8, 'FX\nMISMATCH', COLORS['sovereign'],
         ['$13T EM debt in foreign currency', 'Reserve depletion', 'Import bill pressure']),
        (3, 3, 'SHADOW\nLEVERAGE', COLORS['shadow'],
         ['NBFI assets $220T+', 'Regulatory arbitrage', 'Liquidity transformation']),
        (13, 3, 'USD\nDOMINANCE', COLORS['secondary'],
         ['80% trade settlement', 'Funding currency dependency', 'Sanctions weaponization']),
        (8, 1, 'AI-DRIVEN\nFINANCE', COLORS['nbfi'],
         ['Algorithmic trading 70% volume', 'Flash crash risk', 'Model correlation']),
    ]
    
    for x, y, title, color, details in pillars:
        # Pillar box
        rect = FancyBboxPatch((x-1.8, y-1.3), 3.6, 2.6, boxstyle="round,pad=0.1",
                              facecolor=color, alpha=0.85, edgecolor='white', linewidth=2)
        ax.add_patch(rect)
        ax.text(x, y+0.5, title, ha='center', va='center', fontsize=10,
                color='white', fontweight='bold')
        
        # Details
        for i, detail in enumerate(details):
            ax.text(x, y-0.3-i*0.35, f'• {detail}', ha='center', va='center',
                   fontsize=7, color='white', alpha=0.9)
        
        # Connection to center
        ax.annotate('', xy=(8 + (x-8)*0.3, 5.5 + (y-5.5)*0.3), 
                   xytext=(x, y-1.3 if y > 5.5 else y+1.3),
                   arrowprops=dict(arrowstyle='->', color=COLORS['neutral'], lw=2,
                                  connectionstyle='arc3,rad=0.2'))
    
    # Risk level indicator
    risk_levels = [(2, 0.3, 'LOW', COLORS['positive']), 
                   (6, 0.3, 'MODERATE', COLORS['highlight']),
                   (10, 0.3, 'HIGH', COLORS['accent']),
                   (14, 0.3, 'CRITICAL', COLORS['negative'])]
    
    for x, y, label, color in risk_levels:
        rect = FancyBboxPatch((x-1, y-0.15), 2, 0.5, boxstyle="round,pad=0.02",
                              facecolor=color, alpha=0.8, edgecolor='white')
        ax.add_patch(rect)
        ax.text(x, y, label, ha='center', va='center', fontsize=8, 
                color='white', fontweight='bold')
    
    ax.text(8, 0.1, 'Current Systemic Risk Level: HIGH-TO-CRITICAL', 
            ha='center', fontsize=10, color=COLORS['negative'], fontweight='bold')
    
    return save_figure(fig, 'fig1_1_global_risk_regime.png')


# =============================================================================
# FIGURE 1.2: INTEREST RATE TRAJECTORY AND DURATION RISK
# =============================================================================

def create_interest_rate_duration():
    """
    Figure 1.2: Interest Rate Trajectory and Duration Risk
    """
    fig, axes = plt.subplots(1, 2, figsize=(16, 7))
    
    np.random.seed(42)
    years = np.arange(2008, 2031)
    
    # Panel A: Policy rates
    ax1 = axes[0]
    
    # Historical and projected rates
    fed_rate = np.array([0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.5, 1.0, 
                         1.5, 2.0, 2.5, 1.75, 0.25, 0.25, 0.5, 4.5, 5.25, 5.5, 4.75, 4.0, 3.5, 3.0, 2.75])
    ecb_rate = np.array([1.0, 0.5, 0.25, 0.25, 0.25, 0.05, 0.0, 0.0,
                         0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 2.5, 3.75, 4.0, 3.5, 3.0, 2.75, 2.5, 2.25])
    boe_rate = np.array([1.0, 0.5, 0.25, 0.25, 0.25, 0.25, 0.25, 0.5,
                         0.75, 0.5, 0.75, 0.75, 0.1, 0.1, 0.25, 3.0, 4.25, 5.25, 4.75, 4.0, 3.75, 3.5, 3.25])
    
    ax1.plot(years[:18], fed_rate[:18], color=COLORS['secondary'], linewidth=2.5, 
             label='Federal Reserve', marker='o', markersize=4)
    ax1.plot(years[:18], ecb_rate[:18], color=COLORS['positive'], linewidth=2.5,
             label='ECB', marker='s', markersize=4)
    ax1.plot(years[:18], boe_rate[:18], color=COLORS['accent'], linewidth=2.5,
             label='Bank of England', marker='^', markersize=4)
    
    # Projections (dashed)
    ax1.plot(years[17:], fed_rate[17:], color=COLORS['secondary'], linewidth=2, 
             linestyle='--', alpha=0.7)
    ax1.plot(years[17:], ecb_rate[17:], color=COLORS['positive'], linewidth=2,
             linestyle='--', alpha=0.7)
    ax1.plot(years[17:], boe_rate[17:], color=COLORS['accent'], linewidth=2,
             linestyle='--', alpha=0.7)
    
    # Zero lower bound zone
    ax1.axhspan(0, 0.5, alpha=0.1, color=COLORS['neutral'])
    ax1.text(2022, 0.25, 'ZLB Era', fontsize=8, ha='center', color=COLORS['neutral'])
    
    # High rate zone
    ax1.axhspan(4, 6, alpha=0.1, color=COLORS['negative'])
    ax1.text(2023, 5.5, 'Restrictive\nTerritory', fontsize=8, ha='center', 
            color=COLORS['negative'], fontweight='bold')
    
    ax1.set_xlabel('Year', fontsize=11)
    ax1.set_ylabel('Policy Rate (%)', fontsize=11)
    ax1.set_title('A. Major Central Bank Policy Rates (2008-2030)', fontsize=11, 
                  fontweight='bold', color=COLORS['primary'])
    ax1.legend(loc='upper left', fontsize=8)
    ax1.set_xlim(2008, 2030)
    ax1.set_ylim(-0.5, 7)
    
    # Panel B: Duration losses
    ax2 = axes[1]
    
    countries = ['US', 'UK', 'Japan', 'Germany', 'Italy', 'France', 'Canada', 'Australia']
    duration_losses = [1.8, 2.1, 1.5, 2.3, 3.2, 2.0, 1.4, 1.9]  # % of GDP
    unrealized_losses = [680, 280, 420, 310, 180, 240, 120, 95]  # Billion USD
    
    x = np.arange(len(countries))
    width = 0.35
    
    bars1 = ax2.bar(x - width/2, duration_losses, width, label='Duration Losses (% GDP)',
                    color=COLORS['negative'], edgecolor='white')
    
    ax2_twin = ax2.twinx()
    bars2 = ax2_twin.bar(x + width/2, unrealized_losses, width, label='Unrealized Losses ($B)',
                         color=COLORS['accent'], edgecolor='white', alpha=0.8)
    
    ax2.set_xlabel('Country', fontsize=11)
    ax2.set_ylabel('Duration Losses (% of GDP)', fontsize=11, color=COLORS['negative'])
    ax2_twin.set_ylabel('Unrealized Losses (Billion USD)', fontsize=11, color=COLORS['accent'])
    ax2.set_title('B. Embedded Duration Losses in Bond Portfolios (2024)', fontsize=11,
                  fontweight='bold', color=COLORS['primary'])
    ax2.set_xticks(x)
    ax2.set_xticklabels(countries)
    
    # Combined legend
    lines1, labels1 = ax2.get_legend_handles_labels()
    lines2, labels2 = ax2_twin.get_legend_handles_labels()
    ax2.legend(lines1 + lines2, labels1 + labels2, loc='upper right', fontsize=8)
    
    # Total loss annotation
    total_loss = sum(unrealized_losses)
    ax2.text(0.02, 0.98, f'Total G7+ Duration Losses:\n${total_loss}B', 
             transform=ax2.transAxes, fontsize=9, va='top',
             bbox=dict(boxstyle='round', facecolor='white', alpha=0.9))
    
    fig.suptitle('Figure 1.2. Interest Rate Regime and Duration Risk Accumulation', 
                 fontsize=13, fontweight='bold', color=COLORS['primary'], y=1.02)
    
    plt.tight_layout()
    return save_figure(fig, 'fig1_2_interest_rate_duration.png')


# =============================================================================
# FIGURE 2.1: CONTAGION NETWORK DIAGRAM
# =============================================================================

def create_contagion_network():
    """
    Figure 2.1: Financial Contagion Network Diagram
    Shows sovereign-bank-NBFI-global funding connections
    """
    fig, ax = plt.subplots(figsize=(18, 12))
    ax.set_xlim(0, 18)
    ax.set_ylim(0, 14)
    ax.axis('off')
    
    # Title
    ax.text(9, 13.5, 'Financial Contagion Network: Transmission Channels',
            ha='center', fontsize=16, fontweight='bold', color=COLORS['primary'])
    ax.text(9, 12.8, 'Sovereign ↔ Banks ↔ NBFIs ↔ Global Funding Markets',
            ha='center', fontsize=11, color=COLORS['neutral'])
    
    # Define node positions and properties
    # Format: (x, y, size, color, label, type)
    
    # Sovereign nodes (top layer)
    sovereigns = [
        (3, 10, 1.0, COLORS['sovereign'], 'US\nTreasury', 'Core'),
        (7, 10, 0.8, COLORS['sovereign'], 'Germany', 'Core'),
        (11, 10, 0.7, COLORS['sovereign'], 'Japan', 'Core'),
        (15, 10, 0.9, COLORS['sovereign'], 'UK', 'Core'),
    ]
    
    # Bank nodes (middle layer)
    banks = [
        (2, 6.5, 0.8, COLORS['secondary'], 'GSIBs', 'Global Banks'),
        (5.5, 6.5, 0.7, COLORS['secondary'], 'European\nBanks', 'Regional'),
        (9, 6.5, 0.6, COLORS['secondary'], 'Japanese\nBanks', 'Regional'),
        (12.5, 6.5, 0.7, COLORS['secondary'], 'UK Banks', 'Regional'),
        (16, 6.5, 0.6, COLORS['secondary'], 'EM Banks', 'Emerging'),
    ]
    
    # NBFI nodes (lower middle)
    nbfis = [
        (3, 3.5, 0.9, COLORS['nbfi'], 'Money\nMarket\nFunds', 'Shadow'),
        (7, 3.5, 0.8, COLORS['nbfi'], 'Hedge\nFunds', 'Shadow'),
        (11, 3.5, 0.85, COLORS['nbfi'], 'Pension\nFunds', 'Institutional'),
        (15, 3.5, 0.75, COLORS['shadow'], 'REITs/\nRE Funds', 'Shadow'),
    ]
    
    # Global funding (bottom)
    funding = [
        (9, 1, 1.2, COLORS['accent'], 'GLOBAL USD FUNDING\nMARKET ($13T)', 'Core'),
    ]
    
    # Draw nodes
    def draw_node(x, y, size, color, label, node_type):
        circle = Circle((x, y), size, facecolor=color, edgecolor='white', 
                        linewidth=2, alpha=0.85)
        ax.add_patch(circle)
        ax.text(x, y, label, ha='center', va='center', fontsize=8,
               color='white', fontweight='bold')
    
    # Draw all nodes
    for node in sovereigns + banks + nbfis + funding:
        draw_node(*node)
    
    # Draw connections with varying thickness based on exposure
    def draw_connection(x1, y1, x2, y2, width, style='-', color=COLORS['neutral']):
        ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                   arrowprops=dict(arrowstyle='<->', color=color, lw=width,
                                  linestyle=style, alpha=0.6))
    
    # Sovereign-Bank connections (sovereign debt holdings)
    connections = [
        # Sovereign to Banks
        (3, 9, 2, 7.3, 2, '-', COLORS['sovereign']),      # US-GSIBs
        (3, 9, 5.5, 7.2, 1.5, '-', COLORS['sovereign']),   # US-European
        (7, 9, 5.5, 7.2, 2.5, '-', COLORS['sovereign']),   # Germany-European
        (11, 9, 9, 7.1, 2, '-', COLORS['sovereign']),      # Japan-Japanese
        (15, 9, 12.5, 7.2, 1.5, '-', COLORS['sovereign']), # UK-UK Banks
        
        # Bank to NBFI
        (2, 5.7, 3, 4.4, 2, '-', COLORS['secondary']),     # GSIBs-MMF
        (5.5, 5.8, 7, 4.3, 2.5, '-', COLORS['secondary']), # European-Hedge
        (9, 5.9, 11, 4.35, 1.5, '-', COLORS['secondary']), # Japanese-Pension
        (12.5, 5.8, 15, 4.25, 1.5, '-', COLORS['secondary']), # UK-REITs
        
        # NBFI to Global Funding
        (3, 2.6, 8, 2.2, 3, '-', COLORS['nbfi']),          # MMF-Funding
        (7, 2.7, 8.5, 2.2, 2, '-', COLORS['nbfi']),        # Hedge-Funding
        (11, 2.65, 9.5, 2.2, 1.5, '-', COLORS['nbfi']),    # Pension-Funding
        (15, 2.75, 10, 2.2, 1.5, '-', COLORS['shadow']),   # REIT-Funding
        
        # Bank to Global Funding (direct)
        (2, 5.7, 8, 2.2, 2.5, ':', COLORS['secondary']),   # GSIBs-Funding
        (16, 5.9, 10, 2.2, 2, ':', COLORS['secondary']),   # EM Banks-Funding
    ]
    
    for conn in connections:
        draw_connection(*conn)
    
    # Legend
    legend_items = [
        (1.5, 0.3, COLORS['sovereign'], 'Sovereign Debt'),
        (4.5, 0.3, COLORS['secondary'], 'Banking Sector'),
        (7.5, 0.3, COLORS['nbfi'], 'NBFI/Shadow'),
        (10.5, 0.3, COLORS['accent'], 'Global Funding'),
        (14, 0.3, COLORS['neutral'], 'Contagion Channel'),
    ]
    
    for x, y, color, label in legend_items:
        circle = Circle((x, y), 0.2, facecolor=color, edgecolor='white', linewidth=1)
        ax.add_patch(circle)
        ax.text(x + 0.4, y, label, va='center', fontsize=8)
    
    # Risk transmitter labels
    ax.text(1, 10.5, 'KEY RISK\nTRANSMITTERS:', fontsize=9, fontweight='bold',
           color=COLORS['negative'], va='center')
    ax.text(1, 9.5, '• US Treasury yields', fontsize=8, color=COLORS['neutral'])
    ax.text(1, 9.0, '• USD funding costs', fontsize=8, color=COLORS['neutral'])
    ax.text(1, 8.5, '• NBFI leverage', fontsize=8, color=COLORS['neutral'])
    
    return save_figure(fig, 'fig2_1_contagion_network.png')


# =============================================================================
# FIGURE 2.2: SOVEREIGN-BANK NEXUS
# =============================================================================

def create_sovereign_bank_nexus():
    """
    Figure 2.2: Sovereign-Bank Nexus Analysis
    """
    fig, axes = plt.subplots(1, 2, figsize=(16, 7))
    
    # Panel A: Sovereign debt holdings by banks
    ax1 = axes[0]
    
    countries = ['Italy', 'Japan', 'Spain', 'France', 'Germany', 'UK', 'US']
    domestic_holdings = [22, 18, 15, 12, 10, 8, 5]  # % of bank assets
    foreign_holdings = [3, 2, 4, 6, 8, 5, 3]
    
    x = np.arange(len(countries))
    width = 0.35
    
    bars1 = ax1.barh(x, domestic_holdings, width, label='Domestic Sovereign',
                     color=COLORS['sovereign'], edgecolor='white')
    bars2 = ax1.barh(x + width, foreign_holdings, width, label='Foreign Sovereign',
                     color=COLORS['secondary'], edgecolor='white')
    
    ax1.set_xlabel('Holdings (% of Bank Assets)', fontsize=11)
    ax1.set_title('A. Bank Sovereign Debt Holdings', fontsize=11,
                  fontweight='bold', color=COLORS['primary'])
    ax1.set_yticks(x + width/2)
    ax1.set_yticklabels(countries)
    ax1.legend(loc='lower right', fontsize=8)
    
    # Add risk threshold
    ax1.axvline(x=15, color=COLORS['negative'], linestyle='--', linewidth=2,
               label='High Exposure Threshold')
    
    # Panel B: Doom loop indicator
    ax2 = axes[1]
    
    countries2 = ['Italy', 'Spain', 'Portugal', 'Greece', 'Japan', 'France', 'Germany']
    doom_loop_score = [85, 72, 78, 88, 65, 55, 35]  # Composite score
    
    colors_bar = [COLORS['negative'] if s > 70 else 
                  COLORS['accent'] if s > 50 else 
                  COLORS['positive'] for s in doom_loop_score]
    
    bars = ax2.barh(countries2, doom_loop_score, color=colors_bar, 
                    edgecolor='white', linewidth=0.5)
    
    ax2.axvline(x=70, color=COLORS['negative'], linestyle='--', linewidth=2,
               label='High Risk Threshold')
    ax2.axvline(x=50, color=COLORS['accent'], linestyle='--', linewidth=2,
               label='Moderate Risk')
    
    ax2.set_xlabel('Doom Loop Index (0-100)', fontsize=11)
    ax2.set_title('B. Sovereign-Bank Doom Loop Index', fontsize=11,
                  fontweight='bold', color=COLORS['primary'])
    ax2.legend(loc='lower right', fontsize=8)
    ax2.set_xlim(0, 100)
    
    # Add value labels
    for bar, val in zip(bars, doom_loop_score):
        ax2.text(val + 1, bar.get_y() + bar.get_height()/2, f'{val}',
                va='center', fontsize=9, fontweight='bold')
    
    fig.suptitle('Figure 2.2. Sovereign-Bank Nexus: Mutual Dependence and Risk Transmission',
                 fontsize=13, fontweight='bold', color=COLORS['primary'], y=1.02)
    
    plt.tight_layout()
    return save_figure(fig, 'fig2_2_sovereign_bank_nexus.png')


# =============================================================================
# FIGURE 2.3: NBFI SHADOW BANKING METRICS
# =============================================================================

def create_nbfi_metrics():
    """
    Figure 2.3: Non-Bank Financial Intermediation Metrics
    """
    fig, axes = plt.subplots(1, 2, figsize=(16, 7))
    
    # Panel A: NBFI growth
    ax1 = axes[0]
    
    years = np.arange(2008, 2025)
    np.random.seed(42)
    
    bank_assets = 100 + np.cumsum(np.random.uniform(1, 4, len(years)))
    nbfi_assets = 80 + np.cumsum(np.random.uniform(3, 8, len(years)))
    shadow_assets = 40 + np.cumsum(np.random.uniform(2, 6, len(years)))
    
    # Normalize to 2008 = 100
    bank_assets = bank_assets / bank_assets[0] * 100
    nbfi_assets = nbfi_assets / nbfi_assets[0] * 100
    shadow_assets = shadow_assets / shadow_assets[0] * 100
    
    ax1.plot(years, bank_assets, color=COLORS['secondary'], linewidth=2.5,
             label='Bank Assets', marker='o', markersize=4)
    ax1.plot(years, nbfi_assets, color=COLORS['nbfi'], linewidth=2.5,
             label='NBFI Assets', marker='s', markersize=4)
    ax1.plot(years, shadow_assets, color=COLORS['shadow'], linewidth=2.5,
             label='Shadow Banking', marker='^', markersize=4)
    
    ax1.axhline(y=100, color=COLORS['neutral'], linestyle='--', alpha=0.5)
    ax1.axvspan(2020, 2024, alpha=0.1, color=COLORS['accent'])
    ax1.text(2022, 240, 'COVID Era\nNBFI Expansion', ha='center', fontsize=8,
            color=COLORS['accent'])
    
    ax1.set_xlabel('Year', fontsize=11)
    ax1.set_ylabel('Index (2008 = 100)', fontsize=11)
    ax1.set_title('A. Financial Sector Asset Growth by Type', fontsize=11,
                  fontweight='bold', color=COLORS['primary'])
    ax1.legend(loc='upper left', fontsize=8)
    
    # Panel B: NBFI composition
    ax2 = axes[1]
    
    categories = ['Investment\nFunds', 'Money Market\nFunds', 'Hedge\nFunds', 
                  'Pension\nFunds', 'Insurance', 'REITs', 'Finance\nCompanies']
    assets_2024 = [75, 15, 8, 45, 35, 12, 25]  # Trillion USD
    
    colors_pie = [COLORS['nbfi'], COLORS['secondary'], COLORS['shadow'],
                  COLORS['positive'], COLORS['accent'], COLORS['sovereign'], COLORS['neutral']]
    
    bars = ax2.bar(categories, assets_2024, color=colors_pie, edgecolor='white', linewidth=1)
    
    ax2.set_ylabel('Assets (Trillion USD)', fontsize=11)
    ax2.set_title('B. NBFI Asset Composition (2024)', fontsize=11,
                  fontweight='bold', color=COLORS['primary'])
    
    # Add value labels
    for bar, val in zip(bars, assets_2024):
        ax2.text(bar.get_x() + bar.get_width()/2, val + 1, f'${val}T',
                ha='center', fontsize=9)
    
    ax2.axhline(y=50, color=COLORS['accent'], linestyle='--', linewidth=1.5,
               label='Systemic Threshold ($50T)')
    ax2.legend(fontsize=8)
    
    # Total annotation
    ax2.text(0.98, 0.98, f'Total NBFI Assets:\n${sum(assets_2024)}T',
             transform=ax2.transAxes, fontsize=10, ha='right', va='top',
             bbox=dict(boxstyle='round', facecolor='white', alpha=0.9))
    
    fig.suptitle('Figure 2.3. Non-Bank Financial Intermediation: Growth and Composition',
                 fontsize=13, fontweight='bold', color=COLORS['primary'], y=1.02)
    
    plt.tight_layout()
    return save_figure(fig, 'fig2_3_nbfi_metrics.png')


# =============================================================================
# FIGURE 3.1: STRESS SCENARIO FRAMEWORK
# =============================================================================

def create_stress_scenario_framework():
    """
    Figure 3.1: Stress Scenario Framework Overview
    """
    fig, ax = plt.subplots(figsize=(16, 10))
    ax.set_xlim(0, 16)
    ax.set_ylim(0, 12)
    ax.axis('off')
    
    # Title
    ax.text(8, 11.5, 'Stress Scenario Framework: Shock Transmission Mechanisms',
            ha='center', fontsize=16, fontweight='bold', color=COLORS['primary'])
    
    # Four scenario boxes
    scenarios = [
        (2.5, 7.5, 'RATE SHOCK\n+200 bps', COLORS['secondary'], 
         ['Duration losses: -$1.2T', 'Bank capital: -15%', 'NBFI stress: High', 'Transmission: Global']),
        (8, 7.5, 'FX SHOCK\nUSD +20%', COLORS['accent'],
         ['EM debt burden: +$800B', 'Reserve depletion', 'Import inflation', 'Transmission: EM→Global']),
        (13.5, 7.5, 'COMMODITY\nSHOCK +50%', COLORS['shadow'],
         ['Inflation spike', 'Terms of trade shift', 'Fiscal stress', 'Transmission: Via trade']),
        (5.25, 3, 'CAPITAL FLOW\nREVERSAL', COLORS['negative'],
         ['Portfolio outflows: $500B', 'Currency collapse', 'Liquidity crisis', 'Transmission: Contagion']),
        (10.75, 3, 'COMBINED\nSTRESS', COLORS['sovereign'],
         ['Multiple shocks overlap', 'Amplified losses', 'Policy constraints', 'Transmission: Systemic']),
    ]
    
    for x, y, title, color, details in scenarios:
        rect = FancyBboxPatch((x-2, y-1.8), 4, 3.6, boxstyle="round,pad=0.1",
                              facecolor=color, alpha=0.85, edgecolor='white', linewidth=2)
        ax.add_patch(rect)
        ax.text(x, y+1.2, title, ha='center', va='center', fontsize=10,
                color='white', fontweight='bold')
        
        for i, detail in enumerate(details):
            ax.text(x, y+0.2-i*0.45, f'• {detail}', ha='center', va='center',
                   fontsize=8, color='white', alpha=0.95)
    
    # Arrows showing interconnections
    arrow_style = dict(arrowstyle='->', color=COLORS['neutral'], lw=2, alpha=0.6)
    
    # Horizontal connections
    ax.annotate('', xy=(6, 7.5), xytext=(4.5, 7.5), arrowprops=arrow_style)
    ax.annotate('', xy=(11.5, 7.5), xytext=(10, 7.5), arrowprops=arrow_style)
    
    # Vertical connections
    ax.annotate('', xy=(5.25, 4.8), xytext=(4, 5.7), arrowprops=arrow_style)
    ax.annotate('', xy=(10.75, 4.8), xytext=(12, 5.7), arrowprops=arrow_style)
    
    # Cross connections to combined
    ax.annotate('', xy=(8.75, 3), xytext=(7.25, 3), arrowprops=arrow_style)
    
    # Loss severity indicator
    severity_box = FancyBboxPatch((0.5, 0.3), 15, 1.2, boxstyle="round,pad=0.05",
                                  facecolor=COLORS['light_bg'], edgecolor=COLORS['neutral'], linewidth=1)
    ax.add_patch(severity_box)
    
    ax.text(8, 1.1, 'Projected Global Financial Losses by Scenario (5-Year Horizon)', 
            ha='center', fontsize=10, fontweight='bold', color=COLORS['primary'])
    
    severity_labels = [
        (2.5, 0.55, '$1.5-2.0T', COLORS['secondary']),
        (5.5, 0.55, '$1.8-2.5T', COLORS['accent']),
        (8.5, 0.55, '$1.0-1.5T', COLORS['shadow']),
        (11, 0.55, '$2.0-3.0T', COLORS['negative']),
        (13.5, 0.55, '$3.5-5.0T', COLORS['sovereign']),
    ]
    
    for x, y, text, color in severity_labels:
        ax.text(x, y, text, ha='center', fontsize=9, color=color, fontweight='bold')
    
    return save_figure(fig, 'fig3_1_stress_scenario_framework.png')


# =============================================================================
# FIGURE 3.2: LOSS DISTRIBUTION STRESS TABLE
# =============================================================================

def create_loss_distribution():
    """
    Figure 3.2: Loss Distribution Under Stress Scenarios
    """
    fig, axes = plt.subplots(1, 2, figsize=(16, 8))
    
    # Panel A: Loss waterfall
    ax1 = axes[0]
    
    scenarios = ['Rate\nShock', 'FX\nShock', 'Commodity\nShock', 'Capital\nReversal', 'Combined\nStress']
    
    # Losses by sector (Trillion USD)
    sovereign_losses = [0.3, 0.4, 0.2, 0.5, 0.9]
    bank_losses = [0.8, 0.3, 0.15, 0.4, 1.2]
    nbfi_losses = [0.4, 0.5, 0.15, 0.3, 1.0]
    other_losses = [0.2, 0.2, 0.1, 0.2, 0.5]
    
    x = np.arange(len(scenarios))
    width = 0.6
    
    # Stacked bars
    bars1 = ax1.bar(x, sovereign_losses, width, label='Sovereign', color=COLORS['sovereign'])
    bars2 = ax1.bar(x, bank_losses, width, bottom=sovereign_losses, label='Banks', color=COLORS['secondary'])
    bars3 = ax1.bar(x, nbfi_losses, width, bottom=np.array(sovereign_losses)+np.array(bank_losses), 
                    label='NBFI', color=COLORS['nbfi'])
    bars4 = ax1.bar(x, other_losses, width, 
                    bottom=np.array(sovereign_losses)+np.array(bank_losses)+np.array(nbfi_losses),
                    label='Other', color=COLORS['neutral'])
    
    ax1.set_ylabel('Losses (Trillion USD)', fontsize=11)
    ax1.set_xlabel('Stress Scenario', fontsize=11)
    ax1.set_title('A. Sectoral Loss Distribution by Scenario', fontsize=11,
                  fontweight='bold', color=COLORS['primary'])
    ax1.set_xticks(x)
    ax1.set_xticklabels(scenarios)
    ax1.legend(loc='upper left', fontsize=8)
    
    # Total labels
    totals = [sum(x) for x in zip(sovereign_losses, bank_losses, nbfi_losses, other_losses)]
    for i, total in enumerate(totals):
        ax1.text(i, total + 0.05, f'${total:.1f}T', ha='center', fontsize=9, fontweight='bold')
    
    # Panel B: Solvency gap analysis
    ax2 = axes[1]
    
    countries = ['US', 'UK', 'Japan', 'Germany', 'France', 'Italy', 'Spain', 'EM Average']
    
    # Capital buffer vs losses (as % of capital)
    capital_buffer = [15, 14, 12, 16, 13, 10, 11, 8]
    estimated_losses = [8, 10, 7, 9, 11, 14, 12, 15]
    
    x = np.arange(len(countries))
    width = 0.35
    
    bars1 = ax2.bar(x - width/2, capital_buffer, width, label='Capital Buffer (%)',
                    color=COLORS['positive'], edgecolor='white')
    bars2 = ax2.bar(x + width/2, estimated_losses, width, label='Stress Losses (%)',
                    color=COLORS['negative'], edgecolor='white')
    
    # Solvency gap highlighting
    for i, (buf, loss) in enumerate(zip(capital_buffer, estimated_losses)):
        if loss > buf:
            ax2.fill_between([i-0.5, i+0.5], buf, loss, alpha=0.3, color=COLORS['negative'])
            gap = loss - buf
            ax2.text(i, loss + 0.5, f'Gap: {gap}%', ha='center', fontsize=8,
                    color=COLORS['negative'], fontweight='bold')
    
    ax2.axhline(y=12, color=COLORS['accent'], linestyle='--', linewidth=2,
               label='Minimum Safe Buffer')
    
    ax2.set_ylabel('% of Capital', fontsize=11)
    ax2.set_xlabel('Country/Region', fontsize=11)
    ax2.set_title('B. Solvency Gap Analysis: Capital vs Stress Losses', fontsize=11,
                  fontweight='bold', color=COLORS['primary'])
    ax2.set_xticks(x)
    ax2.set_xticklabels(countries, rotation=45, ha='right')
    ax2.legend(fontsize=8)
    
    fig.suptitle('Figure 3.2. Loss Distribution and Solvency Gap Under Stress Scenarios',
                 fontsize=13, fontweight='bold', color=COLORS['primary'], y=1.02)
    
    plt.tight_layout()
    return save_figure(fig, 'fig3_2_loss_distribution.png')


# =============================================================================
# FIGURE 3.3: FX MISMATCH AND RESERVE ADEQUACY
# =============================================================================

def create_fx_mismatch():
    """
    Figure 3.3: FX Mismatch and Reserve Adequacy Analysis
    """
    fig, axes = plt.subplots(1, 2, figsize=(16, 8))
    
    # Panel A: External debt and FX reserves
    ax1 = axes[0]
    
    countries = ['Turkey', 'Argentina', 'South Africa', 'Indonesia', 'Brazil', 
                 'Mexico', 'India', 'Thailand', 'Poland', 'Malaysia']
    
    short_term_debt = [180, 120, 85, 65, 55, 70, 45, 35, 40, 45]  # % of reserves
    fx_reserves_months = [4, 3, 5, 7, 8, 6, 10, 9, 8, 7]  # months of imports
    
    colors_scatter = [COLORS['negative'] if d > 100 else 
                      COLORS['accent'] if d > 60 else 
                      COLORS['positive'] for d in short_term_debt]
    
    scatter = ax1.scatter(fx_reserves_months, short_term_debt, c=colors_scatter, 
                          s=150, edgecolor='white', linewidth=2)
    
    # Add country labels
    for i, country in enumerate(countries):
        ax1.annotate(country, (fx_reserves_months[i], short_term_debt[i]),
                    xytext=(5, 5), textcoords='offset points', fontsize=8)
    
    # Threshold lines
    ax1.axhline(y=100, color=COLORS['negative'], linestyle='--', linewidth=2,
               label='Critical: Debt > Reserves')
    ax1.axhline(y=60, color=COLORS['accent'], linestyle='--', linewidth=1.5,
               label='Warning Level')
    ax1.axvline(x=3, color=COLORS['negative'], linestyle=':', linewidth=1.5,
               label='Import Coverage Threshold')
    
    # Danger zone
    ax1.fill_between([0, 4], 100, 200, alpha=0.1, color=COLORS['negative'])
    ax1.text(2, 170, 'DANGER\nZONE', ha='center', fontsize=10,
            color=COLORS['negative'], fontweight='bold')
    
    ax1.set_xlabel('FX Reserves (Months of Imports)', fontsize=11)
    ax1.set_ylabel('Short-Term External Debt (% of Reserves)', fontsize=11)
    ax1.set_title('A. Reserve Adequacy vs External Debt Burden', fontsize=11,
                  fontweight='bold', color=COLORS['primary'])
    ax1.legend(loc='upper right', fontsize=8)
    ax1.set_xlim(0, 15)
    ax1.set_ylim(0, 200)
    
    # Panel B: Currency composition of debt
    ax2 = axes[1]
    
    regions = ['EM Asia', 'EM Europe', 'Latin Am.', 'Middle East', 'Africa']
    usd_share = [45, 55, 65, 70, 60]
    eur_share = [15, 30, 10, 5, 20]
    local_share = [35, 12, 20, 20, 15]
    other_share = [5, 3, 5, 5, 5]
    
    x = np.arange(len(regions))
    width = 0.6
    
    ax2.bar(x, usd_share, width, label='USD', color=COLORS['secondary'])
    ax2.bar(x, eur_share, width, bottom=usd_share, label='EUR', color=COLORS['positive'])
    ax2.bar(x, local_share, width, bottom=np.array(usd_share)+np.array(eur_share), 
            label='Local', color=COLORS['nbfi'])
    ax2.bar(x, other_share, width, 
            bottom=np.array(usd_share)+np.array(eur_share)+np.array(local_share),
            label='Other', color=COLORS['neutral'])
    
    ax2.set_ylabel('Share of External Debt (%)', fontsize=11)
    ax2.set_xlabel('Region', fontsize=11)
    ax2.set_title('B. Currency Composition of External Debt', fontsize=11,
                  fontweight='bold', color=COLORS['primary'])
    ax2.set_xticks(x)
    ax2.set_xticklabels(regions)
    ax2.legend(loc='upper right', fontsize=8)
    
    # USD dominance annotation
    ax2.axhline(y=50, color=COLORS['secondary'], linestyle='--', linewidth=1.5,
               alpha=0.5)
    ax2.text(0.02, 0.98, 'USD accounts for\n50%+ of EM external\ndebt in most regions',
             transform=ax2.transAxes, fontsize=8, va='top',
             bbox=dict(boxstyle='round', facecolor='white', alpha=0.9))
    
    fig.suptitle('Figure 3.3. FX Mismatch and Reserve Adequacy in Emerging Markets',
                 fontsize=13, fontweight='bold', color=COLORS['primary'], y=1.02)
    
    plt.tight_layout()
    return save_figure(fig, 'fig3_3_fx_mismatch.png')


# =============================================================================
# FIGURE 4.1: FINANCIAL STABILITY MAP
# =============================================================================

def create_financial_stability_map():
    """
    Figure 4.1: Financial Stability Map - Country Clusters by Vulnerability
    """
    fig, ax = plt.subplots(figsize=(16, 12))
    
    # Define quadrants
    ax.axhline(y=50, color=COLORS['neutral'], linestyle='-', linewidth=1.5, alpha=0.7)
    ax.axvline(x=50, color=COLORS['neutral'], linestyle='-', linewidth=1.5, alpha=0.7)
    
    # Fill quadrants
    ax.fill_between([50, 100], 50, 100, alpha=0.15, color=COLORS['negative'])  # High risk
    ax.fill_between([0, 50], 50, 100, alpha=0.15, color=COLORS['accent'])      # Moderate-high
    ax.fill_between([50, 100], 0, 50, alpha=0.15, color=COLORS['highlight'])   # Moderate
    ax.fill_between([0, 50], 0, 50, alpha=0.15, color=COLORS['positive'])      # Low risk
    
    # Country positions: (financial_stress_index, institutional_capacity)
    countries = {
        # High vulnerability
        'Turkey': (85, 25, COLORS['negative']),
        'Argentina': (90, 20, COLORS['negative']),
        'Egypt': (78, 30, COLORS['negative']),
        'Pakistan': (82, 22, COLORS['negative']),
        
        # Elevated vulnerability
        'South Africa': (72, 45, COLORS['accent']),
        'Brazil': (58, 55, COLORS['accent']),
        'India': (55, 58, COLORS['accent']),
        'Indonesia': (52, 62, COLORS['accent']),
        
        # Moderate
        'Mexico': (48, 58, COLORS['highlight']),
        'Poland': (42, 68, COLORS['highlight']),
        'Thailand': (45, 70, COLORS['highlight']),
        'Malaysia': (50, 65, COLORS['highlight']),
        
        # Low vulnerability
        'US': (35, 88, COLORS['positive']),
        'Germany': (28, 92, COLORS['positive']),
        'Japan': (40, 85, COLORS['positive']),
        'UK': (38, 82, COLORS['positive']),
        'Canada': (32, 88, COLORS['positive']),
        'Australia': (35, 85, COLORS['positive']),
        'Switzerland': (22, 95, COLORS['positive']),
        'Singapore': (30, 90, COLORS['positive']),
        
        # China special case
        'China': (55, 75, COLORS['shadow']),
    }
    
    for country, (x, y, color) in countries.items():
        size = 200 if country in ['US', 'China', 'Japan', 'Germany'] else 150
        ax.scatter(x, y, s=size, c=[color], alpha=0.85, edgecolor='white', linewidth=2)
        ax.annotate(country, (x, y), xytext=(6, 6), textcoords='offset points',
                   fontsize=8, fontweight='bold', color=color)
    
    # Quadrant labels
    ax.text(25, 95, 'TYPE II: Elevated Risk\nModerate Stress / Lower Capacity\n'
                   'Policy Priority: Build buffers, strengthen institutions',
            fontsize=9, ha='center', va='top', color=COLORS['accent'],
            bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    ax.text(75, 95, 'TYPE I: HIGH VULNERABILITY\nHigh Stress / Low Capacity\n'
                   'Policy Priority: Emergency stabilization, IMF programs',
            fontsize=9, ha='center', va='top', color=COLORS['negative'],
            bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    ax.text(75, 5, 'TYPE III: Moderate Risk\nHigh Stress / High Capacity\n'
                  'Policy Priority: Proactive macroprudential action',
            fontsize=9, ha='center', va='bottom', color=COLORS['highlight'],
            bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    ax.text(25, 5, 'TYPE IV: LOW VULNERABILITY\nLow Stress / High Capacity\n'
                  'Policy Priority: Maintain vigilance, lead reforms',
            fontsize=9, ha='center', va='bottom', color=COLORS['positive'],
            bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    ax.set_xlabel('Financial Stress Index (0-100)', fontsize=11)
    ax.set_ylabel('Institutional Capacity Index (0-100)', fontsize=11)
    ax.set_title('Figure 4.1. Financial Stability Map: Country Clusters by Vulnerability (2030 Projection)',
                 fontsize=13, fontweight='bold', color=COLORS['primary'], pad=15)
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    
    # Methodology note
    ax.text(0.02, 0.02, 'SOURCE: CEDX Composite Index combining credit/GDP, FX mismatch, '
             'duration exposure, and governance indicators.',
            transform=ax.transAxes, fontsize=8, color=COLORS['neutral'], style='italic')
    
    return save_figure(fig, 'fig4_1_financial_stability_map.png')


# =============================================================================
# FIGURE 4.2: COMPOSITE RISK INDEX
# =============================================================================

def create_composite_risk_index():
    """
    Figure 4.2: Composite Risk Index Components
    """
    fig, axes = plt.subplots(1, 2, figsize=(16, 8))
    
    # Panel A: Risk index components
    ax1 = axes[0]
    
    countries = ['Turkey', 'Argentina', 'Egypt', 'S. Africa', 'Brazil', 
                 'India', 'Mexico', 'Indonesia', 'Poland', 'Thailand',
                 'US', 'Germany', 'Japan', 'UK']
    
    # Component scores (0-100)
    credit_gdp = [85, 78, 72, 65, 58, 55, 48, 52, 45, 42, 35, 38, 42, 40]
    fx_mismatch = [92, 88, 75, 70, 55, 48, 52, 45, 38, 35, 25, 20, 30, 28]
    duration_exp = [65, 70, 68, 58, 52, 48, 50, 45, 42, 40, 45, 38, 55, 48]
    
    x = np.arange(len(countries))
    width = 0.25
    
    ax1.bar(x - width, credit_gdp, width, label='Credit/GDP Gap', color=COLORS['secondary'])
    ax1.bar(x, fx_mismatch, width, label='FX Mismatch', color=COLORS['accent'])
    ax1.bar(x + width, duration_exp, width, label='Duration Exposure', color=COLORS['sovereign'])
    
    ax1.set_ylabel('Risk Score (0-100)', fontsize=11)
    ax1.set_xlabel('Country', fontsize=11)
    ax1.set_title('A. Composite Risk Index Components by Country', fontsize=11,
                  fontweight='bold', color=COLORS['primary'])
    ax1.set_xticks(x)
    ax1.set_xticklabels(countries, rotation=45, ha='right', fontsize=8)
    ax1.legend(fontsize=8)
    
    # Threshold
    ax1.axhline(y=60, color=COLORS['negative'], linestyle='--', linewidth=1.5,
               label='High Risk Threshold')
    
    # Panel B: Risk index radar
    ax2 = axes[1]
    
    # Create radar chart
    categories = ['Credit/GDP', 'FX Mismatch', 'Duration', 'Bank Health', 
                  'NBFI Risk', 'External Position', 'Governance']
    
    # Sample countries
    turkey = [85, 92, 65, 75, 70, 88, 25]
    brazil = [58, 55, 52, 48, 55, 45, 55]
    us = [35, 25, 45, 40, 65, 20, 88]
    
    angles = np.linspace(0, 2*np.pi, len(categories), endpoint=False).tolist()
    angles += angles[:1]  # Complete the loop
    
    turkey += turkey[:1]
    brazil += brazil[:1]
    us += us[:1]
    
    ax2 = fig.add_subplot(122, projection='polar')
    
    ax2.plot(angles, turkey, 'o-', linewidth=2, label='Turkey', color=COLORS['negative'])
    ax2.fill(angles, turkey, alpha=0.25, color=COLORS['negative'])
    
    ax2.plot(angles, brazil, 'o-', linewidth=2, label='Brazil', color=COLORS['accent'])
    ax2.fill(angles, brazil, alpha=0.25, color=COLORS['accent'])
    
    ax2.plot(angles, us, 'o-', linewidth=2, label='US', color=COLORS['positive'])
    ax2.fill(angles, us, alpha=0.25, color=COLORS['positive'])
    
    ax2.set_xticks(angles[:-1])
    ax2.set_xticklabels(categories, fontsize=8)
    ax2.set_ylim(0, 100)
    ax2.set_title('B. Risk Profile Comparison', fontsize=11,
                  fontweight='bold', color=COLORS['primary'], pad=20)
    ax2.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1), fontsize=8)
    
    fig.suptitle('Figure 4.2. Composite Risk Index: Components and Country Profiles',
                 fontsize=13, fontweight='bold', color=COLORS['primary'], y=1.02)
    
    plt.tight_layout()
    return save_figure(fig, 'fig4_2_composite_risk_index.png')


# =============================================================================
# FIGURE 4.3: EARLY WARNING DASHBOARD
# =============================================================================

def create_early_warning_dashboard():
    """
    Figure 4.3: Early Warning Indicators Dashboard
    """
    fig = plt.figure(figsize=(18, 12))
    
    # Create grid
    gs = fig.add_gridspec(3, 3, hspace=0.3, wspace=0.3)
    
    # Title
    fig.suptitle('Early Warning Indicators Dashboard: Thresholds and Triggers',
                 fontsize=16, fontweight='bold', color=COLORS['primary'], y=0.98)
    
    # Indicator 1: Credit-to-GDP Gap
    ax1 = fig.add_subplot(gs[0, 0])
    countries = ['China', 'Canada', 'Korea', 'UK', 'US', 'Germany']
    credit_gap = [28, 15, 12, 8, 5, 3]
    colors1 = [COLORS['negative'] if g > 10 else COLORS['accent'] if g > 5 else COLORS['positive'] for g in credit_gap]
    ax1.barh(countries, credit_gap, color=colors1)
    ax1.axvline(x=10, color=COLORS['negative'], linestyle='--', linewidth=2)
    ax1.axvline(x=5, color=COLORS['accent'], linestyle='--', linewidth=1.5)
    ax1.set_xlabel('% Points')
    ax1.set_title('Credit-to-GDP Gap', fontweight='bold', fontsize=10)
    ax1.text(10, -0.5, 'Trigger', fontsize=7, color=COLORS['negative'])
    
    # Indicator 2: FX Reserves Coverage
    ax2 = fig.add_subplot(gs[0, 1])
    countries2 = ['Argentina', 'Turkey', 'Egypt', 'S. Africa', 'Brazil', 'India']
    reserves = [3, 4, 5, 5, 8, 10]
    colors2 = [COLORS['negative'] if r < 4 else COLORS['accent'] if r < 6 else COLORS['positive'] for r in reserves]
    ax2.barh(countries2, reserves, color=colors2)
    ax2.axvline(x=3, color=COLORS['negative'], linestyle='--', linewidth=2)
    ax2.axvline(x=6, color=COLORS['accent'], linestyle='--', linewidth=1.5)
    ax2.set_xlabel('Months of Imports')
    ax2.set_title('FX Reserves Coverage', fontweight='bold', fontsize=10)
    
    # Indicator 3: External Debt Service
    ax3 = fig.add_subplot(gs[0, 2])
    countries3 = ['Argentina', 'Turkey', 'Egypt', 'Pakistan', 'S. Africa', 'Brazil']
    debt_service = [45, 38, 32, 35, 22, 18]
    colors3 = [COLORS['negative'] if d > 30 else COLORS['accent'] if d > 20 else COLORS['positive'] for d in debt_service]
    ax3.barh(countries3, debt_service, color=colors3)
    ax3.axvline(x=30, color=COLORS['negative'], linestyle='--', linewidth=2)
    ax3.axvline(x=20, color=COLORS['accent'], linestyle='--', linewidth=1.5)
    ax3.set_xlabel('% of Exports')
    ax3.set_title('External Debt Service', fontweight='bold', fontsize=10)
    
    # Indicator 4: Bank NPL Ratio
    ax4 = fig.add_subplot(gs[1, 0])
    countries4 = ['Greece', 'Italy', 'Portugal', 'Spain', 'Russia', 'India']
    npls = [8, 5, 4, 3, 8, 6]
    colors4 = [COLORS['negative'] if n > 5 else COLORS['accent'] if n > 3 else COLORS['positive'] for n in npls]
    ax4.barh(countries4, npls, color=colors4)
    ax4.axvline(x=5, color=COLORS['negative'], linestyle='--', linewidth=2)
    ax4.axvline(x=3, color=COLORS['accent'], linestyle='--', linewidth=1.5)
    ax4.set_xlabel('% of Loans')
    ax4.set_title('Bank NPL Ratio', fontweight='bold', fontsize=10)
    
    # Indicator 5: Housing Price Gap
    ax5 = fig.add_subplot(gs[1, 1])
    countries5 = ['Korea', 'Canada', 'NZ', 'Australia', 'UK', 'US']
    housing_gap = [35, 28, 25, 20, 15, 10]
    colors5 = [COLORS['negative'] if g > 20 else COLORS['accent'] if g > 10 else COLORS['positive'] for g in housing_gap]
    ax5.barh(countries5, housing_gap, color=colors5)
    ax5.axvline(x=20, color=COLORS['negative'], linestyle='--', linewidth=2)
    ax5.axvline(x=10, color=COLORS['accent'], linestyle='--', linewidth=1.5)
    ax5.set_xlabel('% Above Trend')
    ax5.set_title('Housing Price Gap', fontweight='bold', fontsize=10)
    
    # Indicator 6: Capital Flow Volatility
    ax6 = fig.add_subplot(gs[1, 2])
    countries6 = ['Turkey', 'Argentina', 'Indonesia', 'Brazil', 'Mexico', 'India']
    flow_vol = [25, 22, 15, 18, 12, 10]
    colors6 = [COLORS['negative'] if v > 20 else COLORS['accent'] if v > 15 else COLORS['positive'] for v in flow_vol]
    ax6.barh(countries6, flow_vol, color=colors6)
    ax6.axvline(x=20, color=COLORS['negative'], linestyle='--', linewidth=2)
    ax6.axvline(x=15, color=COLORS['accent'], linestyle='--', linewidth=1.5)
    ax6.set_xlabel('Std Dev (% of GDP)')
    ax6.set_title('Capital Flow Volatility', fontweight='bold', fontsize=10)
    
    # Summary gauge panel
    ax7 = fig.add_subplot(gs[2, :])
    ax7.axis('off')
    
    # Create summary status indicators
    indicators = [
        ('Credit Growth', 'ELEVATED', COLORS['accent']),
        ('FX Pressures', 'HIGH', COLORS['negative']),
        ('Bank Health', 'MODERATE', COLORS['highlight']),
        ('NBFI Leverage', 'ELEVATED', COLORS['accent']),
        ('External Position', 'STRESSED', COLORS['negative']),
        ('Sovereign Risk', 'MODERATE', COLORS['highlight']),
    ]
    
    for i, (name, status, color) in enumerate(indicators):
        x_pos = 1 + i * 2.8
        rect = FancyBboxPatch((x_pos, 0.3), 2.4, 1.4, boxstyle="round,pad=0.05",
                              facecolor=color, alpha=0.85, edgecolor='white', linewidth=2,
                              transform=ax7.transData)
        ax7.add_patch(rect)
        ax7.text(x_pos + 1.2, 1.0, f'{name}\n{status}', ha='center', va='center',
                fontsize=9, color='white', fontweight='bold')
    
    ax7.set_xlim(0, 17)
    ax7.set_ylim(0, 2)
    ax7.text(8.5, 1.9, 'OVERALL SYSTEMIC RISK STATUS: ELEVATED', 
            ha='center', fontsize=12, fontweight='bold', color=COLORS['accent'])
    
    return save_figure(fig, 'fig4_3_early_warning_dashboard.png')


# =============================================================================
# FIGURE 5.1: USD DOMINANCE ANALYSIS
# =============================================================================

def create_usd_dominance():
    """
    Figure 5.1: USD Dominance vs Diversification Trends
    """
    fig, axes = plt.subplots(1, 2, figsize=(16, 7))
    
    # Panel A: Reserve currency composition
    ax1 = axes[0]
    
    years = np.arange(2000, 2025)
    
    # Reserve composition (simplified)
    usd_share = np.array([71, 69, 67, 66, 66, 67, 65, 64, 64, 65, 62, 62, 61, 61, 
                          61, 65, 65, 63, 62, 61, 60, 60, 59, 58, 58])
    eur_share = np.array([18, 19, 20, 22, 24, 25, 25, 26, 26, 26, 27, 27, 28, 28,
                          28, 24, 20, 20, 21, 21, 21, 20, 20, 20, 20])
    other_share = 100 - usd_share - eur_share
    
    ax1.fill_between(years, 0, usd_share, alpha=0.8, color=COLORS['secondary'], label='USD')
    ax1.fill_between(years, usd_share, usd_share + eur_share, alpha=0.8, 
                     color=COLORS['positive'], label='EUR')
    ax1.fill_between(years, usd_share + eur_share, 100, alpha=0.6, 
                     color=COLORS['neutral'], label='Other')
    
    ax1.set_xlabel('Year', fontsize=11)
    ax1.set_ylabel('Share of Global Reserves (%)', fontsize=11)
    ax1.set_title('A. Global Reserve Currency Composition', fontsize=11,
                  fontweight='bold', color=COLORS['primary'])
    ax1.legend(loc='upper right', fontsize=8)
    ax1.set_ylim(0, 100)
    
    # Key events
    ax1.axvline(x=2008, color=COLORS['accent'], linestyle='--', alpha=0.7)
    ax1.text(2008, 90, 'GFC', fontsize=8, ha='center', color=COLORS['accent'])
    ax1.axvline(x=2022, color=COLORS['negative'], linestyle='--', alpha=0.7)
    ax1.text(2022, 85, 'Sanctions', fontsize=8, ha='center', color=COLORS['negative'])
    
    # Panel B: Trade settlement
    ax2 = axes[1]
    
    categories = ['Global Trade\nSettlement', 'FX\nTransactions', 'Cross-Border\nPayments',
                  'Commodity\nPricing', 'Sovereign\nDebt', 'Bank\nFunding']
    
    usd_share_b = [80, 88, 85, 95, 65, 75]
    cny_share = [3, 4, 5, 2, 8, 5]
    eur_share_b = [12, 6, 8, 2, 20, 15]
    other_share_b = [5, 2, 2, 1, 7, 5]
    
    x = np.arange(len(categories))
    width = 0.6
    
    ax2.bar(x, usd_share_b, width, label='USD', color=COLORS['secondary'])
    ax2.bar(x, cny_share, width, bottom=usd_share_b, label='CNY', color=COLORS['accent'])
    ax2.bar(x, eur_share_b, width, bottom=np.array(usd_share_b)+np.array(cny_share),
            label='EUR', color=COLORS['positive'])
    ax2.bar(x, other_share_b, width, 
            bottom=np.array(usd_share_b)+np.array(cny_share)+np.array(eur_share_b),
            label='Other', color=COLORS['neutral'])
    
    ax2.set_ylabel('Share (%)', fontsize=11)
    ax2.set_xlabel('Use Case', fontsize=11)
    ax2.set_title('B. USD Dominance by Use Case (2024)', fontsize=11,
                  fontweight='bold', color=COLORS['primary'])
    ax2.set_xticks(x)
    ax2.set_xticklabels(categories, fontsize=8)
    ax2.legend(fontsize=8)
    
    # Dominance threshold
    ax2.axhline(y=75, color=COLORS['secondary'], linestyle='--', linewidth=1.5,
               alpha=0.5)
    ax2.text(0.02, 0.98, 'USD dominance remains\nabove 75% in critical\nuse cases',
             transform=ax2.transAxes, fontsize=8, va='top',
             bbox=dict(boxstyle='round', facecolor='white', alpha=0.9))
    
    fig.suptitle('Figure 5.1. USD Dominance: Narrative vs Measurable Shifts',
                 fontsize=13, fontweight='bold', color=COLORS['primary'], y=1.02)
    
    plt.tight_layout()
    return save_figure(fig, 'fig5_1_usd_dominance.png')


# =============================================================================
# FIGURE 5.2: AI-DRIVEN FINANCE RISKS
# =============================================================================

def create_ai_finance_risks():
    """
    Figure 5.2: AI-Driven Finance Risk Analysis
    """
    fig, axes = plt.subplots(1, 2, figsize=(16, 7))
    
    # Panel A: Algorithmic trading share
    ax1 = axes[0]
    
    years = np.arange(2010, 2026)
    algo_share = [35, 40, 45, 50, 55, 58, 60, 62, 65, 68, 70, 72, 74, 76, 78, 80]
    
    ax1.plot(years, algo_share, color=COLORS['nbfi'], linewidth=3, marker='o', markersize=5)
    ax1.fill_between(years, algo_share, alpha=0.2, color=COLORS['nbfi'])
    
    # Risk thresholds
    ax1.axhline(y=70, color=COLORS['accent'], linestyle='--', linewidth=2,
               label='Correlation Risk Threshold')
    ax1.axhline(y=80, color=COLORS['negative'], linestyle='--', linewidth=2,
               label='Systemic Risk Threshold')
    
    ax1.axvspan(2024, 2026, alpha=0.1, color=COLORS['negative'])
    ax1.text(2025, 65, 'Projected\nHigh Risk\nZone', ha='center', fontsize=8,
            color=COLORS['negative'])
    
    ax1.set_xlabel('Year', fontsize=11)
    ax1.set_ylabel('Share of Trading Volume (%)', fontsize=11)
    ax1.set_title('A. Algorithmic Trading Market Share', fontsize=11,
                  fontweight='bold', color=COLORS['primary'])
    ax1.legend(loc='lower right', fontsize=8)
    ax1.set_ylim(30, 85)
    
    # Panel B: Flash crash frequency
    ax2 = axes[1]
    
    years2 = np.arange(2010, 2025)
    flash_crashes = [1, 1, 2, 1, 3, 2, 2, 4, 3, 5, 6, 7, 8, 9, 10]  # Events per year
    
    colors_bar = [COLORS['positive'] if f < 3 else 
                  COLORS['accent'] if f < 6 else 
                  COLORS['negative'] for f in flash_crashes]
    
    ax2.bar(years2, flash_crashes, color=colors_bar, edgecolor='white', width=0.8)
    
    ax2.axhline(y=5, color=COLORS['accent'], linestyle='--', linewidth=2,
               label='Elevated Frequency')
    ax2.axhline(y=8, color=COLORS['negative'], linestyle='--', linewidth=2,
               label='Crisis Level')
    
    ax2.set_xlabel('Year', fontsize=11)
    ax2.set_ylabel('Number of Flash Crash Events', fontsize=11)
    ax2.set_title('B. Flash Crash Event Frequency', fontsize=11,
                  fontweight='bold', color=COLORS['primary'])
    ax2.legend(loc='upper left', fontsize=8)
    
    # Annotation
    ax2.annotate('2010 Flash Crash\n(May 6)', xy=(2010, 1), xytext=(2012, 5),
                fontsize=8, ha='center',
                arrowprops=dict(arrowstyle='->', color=COLORS['neutral']))
    
    fig.suptitle('Figure 5.2. AI-Driven Finance: Systemic Risk Implications',
                 fontsize=13, fontweight='bold', color=COLORS['primary'], y=1.02)
    
    plt.tight_layout()
    return save_figure(fig, 'fig5_2_ai_finance_risks.png')


# =============================================================================
# FIGURE 6.1: MACROPRUDENTIAL PLAYBOOK
# =============================================================================

def create_macroprudential_playbook():
    """
    Figure 6.1: Macroprudential Policy Playbook
    """
    fig, ax = plt.subplots(figsize=(18, 12))
    ax.set_xlim(0, 18)
    ax.set_ylim(0, 14)
    ax.axis('off')
    
    # Title
    ax.text(9, 13.5, 'Macroprudential Policy Playbook: Tools and Triggers',
            ha='center', fontsize=16, fontweight='bold', color=COLORS['primary'])
    
    # Three columns: Risk Type, Tool, Trigger
    columns = [
        ('CREDIT BOOM', 3, [
            ('Countercyclical\nCapital Buffer', 'CCyB: 0-2.5%', 'Credit/GDP gap > 5pp'),
            ('Sectoral\nCapital Requirements', 'Risk weights: 50-150%', 'Sector credit > 20% y/y'),
            ('LTV Limits', 'Max LTV: 60-90%', 'House prices > 15% trend'),
            ('DTI Limits', 'Max DTI: 4-6x income', 'Household debt > 80% GDP'),
        ]),
        ('FX RISK', 9, [
            ('FX Liquidity\nRequirements', 'HQLA: 25-50% FX', 'FX mismatch > 30%'),
            ('FX Position\nLimits', 'Net open: ±5-20%', 'Currency stress > 20%'),
            ('Reserve\nRequirements', 'RR: 5-15% FX deposits', 'Coverage < 4 months'),
            ('FX Hedging\nMandates', 'Min hedge: 50-80%', 'Short-term debt > 60%'),
        ]),
        ('NBFI/SHADOW', 15, [
            ('Leverage\nLimits', 'Max leverage: 8-15x', 'Leverage > 10x avg'),
            ('Liquidity\nBuffers', 'Min cash: 5-15%', 'Redemption pressure'),
            ('Margin\nRequirements', 'Initial margin: 15-50%', 'Volatility spike > 50%'),
            ('Reporting\nRequirements', 'Quarterly disclosure', 'Size > $50B AUM'),
        ]),
    ]
    
    for col_title, x_base, tools in columns:
        # Column header
        rect = FancyBboxPatch((x_base-2.5, 11), 5, 1.5, boxstyle="round,pad=0.1",
                              facecolor=COLORS['primary'], edgecolor='white', linewidth=2)
        ax.add_patch(rect)
        ax.text(x_base, 11.75, col_title, ha='center', va='center',
               fontsize=12, color='white', fontweight='bold')
        
        # Tool boxes
        for i, (tool, param, trigger) in enumerate(tools):
            y_pos = 9 - i * 2.5
            
            # Tool box
            rect1 = FancyBboxPatch((x_base-2.5, y_pos-0.8), 5, 2, 
                                  boxstyle="round,pad=0.05",
                                  facecolor=COLORS['light_bg'], 
                                  edgecolor=COLORS['primary'], linewidth=1.5)
            ax.add_patch(rect1)
            
            ax.text(x_base, y_pos+0.6, tool, ha='center', va='center',
                   fontsize=10, fontweight='bold', color=COLORS['primary'])
            ax.text(x_base, y_pos-0.1, param, ha='center', va='center',
                   fontsize=9, color=COLORS['secondary'])
            ax.text(x_base, y_pos-0.6, f'Trigger: {trigger}', ha='center', va='center',
                   fontsize=7, color=COLORS['accent'], style='italic')
    
    # Implementation note
    note_box = FancyBboxPatch((1, 0.3), 16, 1.2, boxstyle="round,pad=0.1",
                              facecolor=COLORS['highlight'], alpha=0.2,
                              edgecolor=COLORS['accent'], linewidth=1)
    ax.add_patch(note_box)
    ax.text(9, 0.9, 'IMPLEMENTATION NOTE: Deploy tools incrementally. Start with softer measures (guidance, reporting) '
           'before hard limits. Coordinate across jurisdictions to prevent regulatory arbitrage.',
           ha='center', va='center', fontsize=9, color=COLORS['neutral'])
    
    return save_figure(fig, 'fig6_1_macroprudential_playbook.png')


# =============================================================================
# FIGURE 6.2: NBFI SUPERVISION BLUEPRINT
# =============================================================================

def create_nbfi_supervision():
    """
    Figure 6.2: NBFI Supervision Blueprint
    """
    fig, ax = plt.subplots(figsize=(16, 10))
    ax.set_xlim(0, 16)
    ax.set_ylim(0, 12)
    ax.axis('off')
    
    # Title
    ax.text(8, 11.5, 'NBFI Supervision Blueprint: Expanding the Regulatory Perimeter',
            ha='center', fontsize=16, fontweight='bold', color=COLORS['primary'])
    
    # Three pillars
    pillars = [
        ('DATA\nCOLLECTION', 3, COLORS['secondary'], [
            '• Asset/liability reporting',
            '• Leverage metrics',
            '• Liquidity profiles',
            '• Interconnectedness mapping',
            '• FX exposure tracking',
        ]),
        ('STRESS\nTESTING', 8, COLORS['accent'], [
            '• Scenario analysis',
            '• Reverse stress tests',
            '• Contagion modeling',
            '• Liquidity stress tests',
            '• Concentration risk',
        ]),
        ('PERIMETER\nEXPANSION', 13, COLORS['shadow'], [
            '• Designate SIFIs',
            '• Prudential standards',
            '• Resolution planning',
            '• Enhanced disclosure',
            '• Cross-border coordination',
        ]),
    ]
    
    for title, x, color, items in pillars:
        # Pillar box
        rect = FancyBboxPatch((x-2.2, 3), 4.4, 7, boxstyle="round,pad=0.1",
                              facecolor=color, alpha=0.85, edgecolor='white', linewidth=2)
        ax.add_patch(rect)
        
        ax.text(x, 9, title, ha='center', va='center', fontsize=12,
               color='white', fontweight='bold')
        
        for i, item in enumerate(items):
            ax.text(x, 7.5 - i*0.8, item, ha='center', va='center',
                   fontsize=9, color='white')
    
    # Timeline at bottom
    timeline_y = 1.5
    phases = [
        (2, 'Phase 1\n(0-12 mo)', 'Data infrastructure'),
        (6, 'Phase 2\n(12-24 mo)', 'Stress testing'),
        (10, 'Phase 3\n(24-36 mo)', 'Perimeter rules'),
        (14, 'Phase 4\n(36-48 mo)', 'Full implementation'),
    ]
    
    for x, phase, desc in phases:
        circle = Circle((x, timeline_y), 0.4, facecolor=COLORS['primary'],
                        edgecolor='white', linewidth=2)
        ax.add_patch(circle)
        ax.text(x, timeline_y, str(phases.index((x, phase, desc))+1),
               ha='center', va='center', fontsize=10, color='white', fontweight='bold')
        ax.text(x, timeline_y-0.8, phase, ha='center', fontsize=8,
               color=COLORS['primary'], fontweight='bold')
        ax.text(x, timeline_y-1.5, desc, ha='center', fontsize=7,
               color=COLORS['neutral'])
    
    # Connecting line
    ax.plot([2, 14], [timeline_y, timeline_y], color=COLORS['primary'], lw=2, zorder=0)
    
    return save_figure(fig, 'fig6_2_nbfi_supervision.png')


# =============================================================================
# FIGURE 7.1: IFI TECHNICAL ASSISTANCE MENU
# =============================================================================

def create_ifi_assistance():
    """
    Figure 7.1: International Financial Institution Technical Assistance Menu
    """
    fig, ax = plt.subplots(figsize=(16, 10))
    ax.set_xlim(0, 16)
    ax.set_ylim(0, 12)
    ax.axis('off')
    
    # Title
    ax.text(8, 11.5, 'IFI Technical Assistance Menu: Capacity Building Priorities',
            ha='center', fontsize=16, fontweight='bold', color=COLORS['primary'])
    
    # IFI boxes
    institutions = [
        ('IMF', 2.5, [
            ('Early Warning\nSystems', '$5-10M'),
            ('FSAP\nEnhancement', '$8-15M'),
            ('Crisis\nSimulation', '$3-5M'),
        ]),
        ('World Bank', 8, [
            ('Supervisory\nCapacity', '$15-25M'),
            ('Data\nInfrastructure', '$20-40M'),
            ('Legal\nFramework', '$10-20M'),
        ]),
        ('BIS/FSB', 13.5, [
            ('Standards\nImplementation', '$5-8M'),
            ('Peer\nReviews', '$2-4M'),
            ('Resolution\nPlanning', '$5-10M'),
        ]),
    ]
    
    colors_inst = [COLORS['secondary'], COLORS['positive'], COLORS['accent']]
    
    for (inst, x, services), color in zip(institutions, colors_inst):
        # Institution header
        rect = FancyBboxPatch((x-2, 8.5), 4, 1.5, boxstyle="round,pad=0.1",
                              facecolor=color, edgecolor='white', linewidth=2)
        ax.add_patch(rect)
        ax.text(x, 9.25, inst, ha='center', va='center', fontsize=14,
               color='white', fontweight='bold')
        
        # Service boxes
        for i, (service, cost) in enumerate(services):
            y = 6.5 - i * 2
            
            rect = FancyBboxPatch((x-1.8, y-0.6), 3.6, 1.4, 
                                  boxstyle="round,pad=0.05",
                                  facecolor=COLORS['light_bg'],
                                  edgecolor=color, linewidth=1.5)
            ax.add_patch(rect)
            
            ax.text(x, y+0.2, service, ha='center', va='center',
                   fontsize=9, color=COLORS['primary'], fontweight='bold')
            ax.text(x, y-0.3, cost, ha='center', va='center',
                   fontsize=8, color=COLORS['accent'])
    
    # Priority ranking
    ax.text(8, 1.5, 'PRIORITY RANKING', ha='center', fontsize=12, fontweight='bold',
           color=COLORS['primary'])
    
    priorities = [
        ('1. Early Warning Systems', 'HIGH', COLORS['negative']),
        ('2. NBFI Data Collection', 'HIGH', COLORS['negative']),
        ('3. Stress Testing Capacity', 'MEDIUM-HIGH', COLORS['accent']),
        ('4. Crisis Management Frameworks', 'MEDIUM', COLORS['highlight']),
    ]
    
    for i, (priority, level, color) in enumerate(priorities):
        x = 3 + i * 3
        rect = FancyBboxPatch((x-1.3, 0.3), 2.6, 0.8, boxstyle="round,pad=0.02",
                              facecolor=color, alpha=0.7, edgecolor='white')
        ax.add_patch(rect)
        ax.text(x, 0.7, priority, ha='center', fontsize=7, color='white', fontweight='bold')
        ax.text(x, 0.35, level, ha='center', fontsize=6, color='white')
    
    return save_figure(fig, 'fig7_1_ifi_assistance.png')


# =============================================================================
# FIGURE A.1: HISTORICAL CRISIS COMPARISON
# =============================================================================

def create_crisis_comparison():
    """
    Figure A.1: Historical Crisis Comparison
    """
    fig, axes = plt.subplots(1, 2, figsize=(16, 7))
    
    # Panel A: Crisis timeline
    ax1 = axes[0]
    
    crises = [
        ('LTCM\n1998', 1998, 15),
        ('Dot-com\n2000', 2000, 25),
        ('GFC\n2008', 2008, 100),
        ('Euro\nDebt 2010', 2010, 45),
        ('China\n2015', 2015, 35),
        ('COVID\n2020', 2020, 75),
        ('Bank\nRuns 2023', 2023, 40),
    ]
    
    for name, year, impact in crises:
        color = COLORS['negative'] if impact > 50 else COLORS['accent'] if impact > 30 else COLORS['highlight']
        ax1.scatter(year, impact, s=impact*3, c=[color], alpha=0.7, edgecolor='white', linewidth=2)
        ax1.annotate(name, (year, impact), xytext=(0, 10), textcoords='offset points',
                    ha='center', fontsize=8)
    
    ax1.set_xlabel('Year', fontsize=11)
    ax1.set_ylabel('Impact Index (0-100)', fontsize=11)
    ax1.set_title('A. Financial Crisis Timeline and Severity', fontsize=11,
                  fontweight='bold', color=COLORS['primary'])
    ax1.set_xlim(1995, 2030)
    ax1.set_ylim(0, 120)
    
    # Future projection
    ax1.axvspan(2025, 2030, alpha=0.1, color=COLORS['negative'])
    ax1.scatter([2028], [80], s=200, c=[COLORS['negative']], alpha=0.5, 
                edgecolor='white', linewidth=2, marker='*')
    ax1.text(2028, 95, 'Projected\n2030 Risk', ha='center', fontsize=8,
            color=COLORS['negative'])
    
    # Panel B: Crisis type frequency
    ax2 = axes[1]
    
    crisis_types = ['Banking', 'Currency', 'Sovereign\nDebt', 'Asset\nPrice', 
                    'Liquidity', 'Contagion']
    pre_2008 = [15, 25, 12, 18, 8, 10]
    post_2008 = [8, 15, 18, 22, 20, 18]
    
    x = np.arange(len(crisis_types))
    width = 0.35
    
    ax2.bar(x - width/2, pre_2008, width, label='Pre-2008', color=COLORS['secondary'])
    ax2.bar(x + width/2, post_2008, width, label='Post-2008', color=COLORS['accent'])
    
    ax2.set_ylabel('Frequency Index', fontsize=11)
    ax2.set_xlabel('Crisis Type', fontsize=11)
    ax2.set_title('B. Crisis Type Frequency: Pre vs Post 2008', fontsize=11,
                  fontweight='bold', color=COLORS['primary'])
    ax2.set_xticks(x)
    ax2.set_xticklabels(crisis_types, fontsize=9)
    ax2.legend(fontsize=8)
    
    # Key insight
    ax2.text(0.98, 0.98, 'Key Shift: From banking/currency\ncrises to liquidity/asset price events.\nShadow banking amplifies transmission.',
             transform=ax2.transAxes, fontsize=8, va='top', ha='right',
             bbox=dict(boxstyle='round', facecolor='white', alpha=0.9))
    
    fig.suptitle('Figure A.1. Historical Crisis Comparison: Patterns and Lessons',
                 fontsize=13, fontweight='bold', color=COLORS['primary'], y=1.02)
    
    plt.tight_layout()
    return save_figure(fig, 'fig_a1_crisis_comparison.png')


# =============================================================================
# FIGURE A.2: REGIONAL VULNERABILITY HEAT MAP
# =============================================================================

def create_regional_heatmap():
    """
    Figure A.2: Regional Vulnerability Heat Map
    """
    fig, ax = plt.subplots(figsize=(16, 10))
    
    # Create heat map data
    regions = ['North America', 'Western Europe', 'Eastern Europe', 'East Asia',
               'Southeast Asia', 'South Asia', 'Latin America', 'Middle East', 'Africa']
    indicators = ['Credit Gap', 'FX Risk', 'Bank Health', 'NBFI Risk', 
                  'Sovereign Risk', 'External Position']
    
    # Vulnerability scores (0-100)
    np.random.seed(42)
    data = np.array([
        [35, 25, 40, 55, 30, 20],  # North America
        [42, 30, 45, 60, 38, 25],  # Western Europe
        [55, 65, 50, 45, 55, 60],  # Eastern Europe
        [48, 35, 42, 50, 45, 30],  # East Asia
        [52, 55, 48, 52, 50, 55],  # Southeast Asia
        [58, 70, 55, 45, 60, 65],  # South Asia
        [60, 72, 58, 48, 55, 70],  # Latin America
        [55, 85, 52, 42, 65, 80],  # Middle East
        [62, 88, 60, 40, 70, 85],  # Africa
    ])
    
    # Create heat map
    im = ax.imshow(data, cmap='RdYlGn_r', aspect='auto', vmin=0, vmax=100)
    
    # Set ticks
    ax.set_xticks(np.arange(len(indicators)))
    ax.set_yticks(np.arange(len(regions)))
    ax.set_xticklabels(indicators, fontsize=10)
    ax.set_yticklabels(regions, fontsize=10)
    
    # Rotate x labels
    plt.setp(ax.get_xticklabels(), rotation=45, ha='right', rotation_mode='anchor')
    
    # Add value annotations
    for i in range(len(regions)):
        for j in range(len(indicators)):
            value = data[i, j]
            color = 'white' if value > 50 else 'black'
            ax.text(j, i, f'{value}', ha='center', va='center', color=color, fontsize=9)
    
    # Add colorbar
    cbar = ax.figure.colorbar(im, ax=ax, shrink=0.8)
    cbar.ax.set_ylabel('Vulnerability Score', rotation=-90, va='bottom', fontsize=10)
    
    ax.set_title('Figure A.2. Regional Vulnerability Heat Map: Multi-Indicator Assessment',
                 fontsize=13, fontweight='bold', color=COLORS['primary'], pad=15)
    
    # Add threshold lines
    for i in range(len(indicators) + 1):
        ax.axvline(x=i-0.5, color='white', linewidth=2)
    for i in range(len(regions) + 1):
        ax.axhline(y=i-0.5, color='white', linewidth=2)
    
    return save_figure(fig, 'fig_a2_regional_heatmap.png')


# =============================================================================
# MAIN EXECUTION
# =============================================================================

def main():
    """
    Generate all figures for the Financial Stability Map of 2030 report.
    """
    print("=" * 70)
    print("THE FINANCIAL STABILITY MAP OF 2030 - VISUALIZATION SUITE")
    print("=" * 70)
    print(f"\nOutput directory: {os.path.abspath(OUTPUT_DIR)}")
    print("-" * 70)
    
    # Generate all figures
    figures = [
        ("Global Risk Regime", create_global_risk_regime),
        ("Interest Rate Duration", create_interest_rate_duration),
        ("Contagion Network", create_contagion_network),
        ("Sovereign-Bank Nexus", create_sovereign_bank_nexus),
        ("NBFI Metrics", create_nbfi_metrics),
        ("Stress Scenario Framework", create_stress_scenario_framework),
        ("Loss Distribution", create_loss_distribution),
        ("FX Mismatch", create_fx_mismatch),
        ("Financial Stability Map", create_financial_stability_map),
        ("Composite Risk Index", create_composite_risk_index),
        ("Early Warning Dashboard", create_early_warning_dashboard),
        ("USD Dominance", create_usd_dominance),
        ("AI Finance Risks", create_ai_finance_risks),
        ("Macroprudential Playbook", create_macroprudential_playbook),
        ("NBFI Supervision", create_nbfi_supervision),
        ("IFI Assistance", create_ifi_assistance),
        ("Crisis Comparison", create_crisis_comparison),
        ("Regional Heat Map", create_regional_heatmap),
    ]
    
    success_count = 0
    for name, func in figures:
        try:
            func()
            success_count += 1
        except Exception as e:
            print(f"✗ Error generating {name}: {str(e)}")
    
    print("-" * 70)
    print(f"\n✓ Successfully generated {success_count}/{len(figures)} figures")
    print(f"✓ All files saved to: {os.path.abspath(OUTPUT_DIR)}")
    print("=" * 70)


if __name__ == "__main__":
    main()
